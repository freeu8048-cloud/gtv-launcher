package com.example.gtvlauncher

import android.graphics.drawable.Drawable
import org.json.JSONArray
import org.json.JSONObject

fun JSONObject.s(k: String): String = if (isNull(k)) "" else optString(k, "")

data class AppItem(val pkg: String, val label: String, val image: Drawable, val banner: Boolean)

data class Title(
    val id: Long, val type: String, val name: String, val overview: String,
    val backdrop: String, val poster: String, val rating: Double, val year: String
) {
    val image: String get() = if (backdrop.isNotEmpty()) backdrop else poster
    val kind: String get() = if (type == "tv") "Show" else "Movie"

    fun toJson(): JSONObject = JSONObject().put("id", id).put("t", type).put("n", name)
        .put("o", overview).put("b", backdrop).put("p", poster).put("r", rating).put("y", year)

    companion object {
        fun fromJson(o: JSONObject): Title = Title(
            o.getLong("id"), o.getString("t"), o.getString("n"), o.getString("o"),
            o.getString("b"), o.getString("p"), o.getDouble("r"), o.getString("y")
        )
    }
}

data class ContentRow(val title: String, val items: List<Title>)

class Tile(var emoji: String, var label: String, val action: () -> Unit)

fun rowsToJson(rows: List<ContentRow>): String {
    val a = JSONArray()
    for (r in rows) {
        val items = JSONArray()
        for (t in r.items) items.put(t.toJson())
        a.put(JSONObject().put("t", r.title).put("items", items))
    }
    return a.toString()
}

fun rowsFromJson(s: String): List<ContentRow> {
    val out = ArrayList<ContentRow>()
    try {
        val a = JSONArray(s)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val arr = o.getJSONArray("items")
            val items = ArrayList<Title>()
            for (j in 0 until arr.length()) items.add(Title.fromJson(arr.getJSONObject(j)))
            out.add(ContentRow(o.getString("t"), items))
        }
    } catch (e: Exception) {
    }
    return out
}
