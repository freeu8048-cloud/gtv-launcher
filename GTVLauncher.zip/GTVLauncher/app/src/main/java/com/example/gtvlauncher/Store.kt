package com.example.gtvlauncher

import android.content.Context
import org.json.JSONArray

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("gtv2", Context.MODE_PRIVATE)

    var theme: Int
        get() = p.getInt("theme", 0)
        set(v) { p.edit().putInt("theme", v).apply() }

    var showHidden: Boolean
        get() = p.getBoolean("showHidden", false)
        set(v) { p.edit().putBoolean("showHidden", v).apply() }

    var clock24: Boolean
        get() = p.getBoolean("clock24", false)
        set(v) { p.edit().putBoolean("clock24", v).apply() }


    var reduceMotion: Boolean
        get() = p.getBoolean("reduceMotion", false)
        set(v) { p.edit().putBoolean("reduceMotion", v).apply() }

    var idleMinutes: Int
        get() = p.getInt("idle", 2)
        set(v) { p.edit().putInt("idle", v).apply() }

    var profile: String
        get() = p.getString("profile", "") ?: ""
        set(v) { p.edit().putString("profile", v).apply() }

    fun order(): MutableList<String> =
        (p.getString("order", "") ?: "").split(",").filter { it.isNotBlank() }.toMutableList()
    fun setOrder(l: List<String>) { p.edit().putString("order", l.joinToString(",")).apply() }

    fun cacheGetAny(key: String): String? = p.getString("cd_" + key, null)

    fun hasHidden(): Boolean = p.contains("hidden")
    fun hidden(): MutableSet<String> {
        val s = HashSet<String>()
        val x = p.getStringSet("hidden", null)
        if (x != null) s.addAll(x)
        return s
    }
    fun setHidden(s: Set<String>) { p.edit().putStringSet("hidden", HashSet<String>(s)).apply() }

    fun pinned(): MutableList<String> =
        (p.getString("pinned", "") ?: "").split(",").filter { it.isNotBlank() }.toMutableList()
    fun setPinned(l: List<String>) { p.edit().putString("pinned", l.joinToString(",")).apply() }

    fun launchCount(pkg: String): Int = p.getInt("lc_" + pkg, 0)
    fun recents(): List<String> =
        (p.getString("recents", "") ?: "").split(",").filter { it.isNotBlank() }
    fun recordLaunch(pkg: String) {
        val r = recents().toMutableList()
        r.remove(pkg)
        r.add(0, pkg)
        p.edit().putInt("lc_" + pkg, launchCount(pkg) + 1)
            .putString("recents", r.take(14).joinToString(",")).apply()
    }

    fun myList(): MutableList<Title> {
        val out = ArrayList<Title>()
        try {
            val a = JSONArray(p.getString("mylist", "[]"))
            for (i in 0 until a.length()) out.add(Title.fromJson(a.getJSONObject(i)))
        } catch (e: Exception) {
        }
        return out
    }
    fun inList(t: Title): Boolean = myList().any { it.id == t.id && it.type == t.type }
    fun toggleList(t: Title): Boolean {
        val l = myList()
        val idx = l.indexOfFirst { it.id == t.id && it.type == t.type }
        val added: Boolean
        if (idx >= 0) {
            l.removeAt(idx)
            added = false
        } else {
            l.add(0, t)
            added = true
        }
        val a = JSONArray()
        for (x in l) a.put(x.toJson())
        p.edit().putString("mylist", a.toString()).apply()
        return added
    }

    fun cacheGet(key: String, maxAgeMs: Long): String? {
        val t = p.getLong("ct_" + key, 0L)
        return if (System.currentTimeMillis() - t < maxAgeMs) p.getString("cd_" + key, null) else null
    }
    fun cachePut(key: String, data: String) {
        p.edit().putString("cd_" + key, data).putLong("ct_" + key, System.currentTimeMillis()).apply()
    }
    fun clearCache() {
        val keys = p.all.keys.toList()
        val e = p.edit()
        for (k in keys) if (k.startsWith("cd_") || k.startsWith("ct_")) e.remove(k)
        e.apply()
    }
    fun resetLayout() {
        p.edit().remove("hidden").remove("pinned").remove("recents").remove("order").apply()
    }
}
