package com.example.gtvlauncher

import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

data class AppItem(val pkg: String, val label: String, val image: Drawable, val intent: Intent)

class MainActivity : AppCompatActivity() {
    private lateinit var clock: TextView
    private lateinit var greeting: TextView
    private lateinit var heroTitle: TextView
    private lateinit var heroSub: TextView
    private lateinit var row: RecyclerView
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            clock.text = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            greeting.text = when { h < 12 -> "Good morning"; h < 17 -> "Good afternoon"; else -> "Good evening" }
            handler.postDelayed(this, 30_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        clock = findViewById(R.id.clock)
        greeting = findViewById(R.id.greeting)
        heroTitle = findViewById(R.id.heroTitle)
        heroSub = findViewById(R.id.heroSub)
        row = findViewById(R.id.appRow)
        row.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
        val apps = loadApps()
        row.adapter = AppAdapter(apps) { app ->
            heroTitle.text = app.label
            heroSub.text = "Press OK to open"
        }
        if (apps.isNotEmpty()) {
            heroTitle.text = apps[0].label
            heroSub.text = "Press OK to open"
        }
        row.post { row.getChildAt(0)?.requestFocus() }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        val seen = HashSet<String>()
        val result = ArrayList<AppItem>()
        val categories = listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)
        for (cat in categories) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
            val list: List<ResolveInfo> = pm.queryIntentActivities(q, 0)
            for (ri in list) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || !seen.add(pkg)) continue
                val image = ri.activityInfo.loadBanner(pm)
                    ?: ri.activityInfo.applicationInfo.loadBanner(pm)
                    ?: ri.loadIcon(pm)
                val launch = Intent(Intent.ACTION_MAIN).addCategory(cat)
                    .setClassName(pkg, ri.activityInfo.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                result.add(AppItem(pkg, ri.loadLabel(pm).toString(), image, launch))
            }
        }
        return result.sortedBy { it.label.lowercase() }
    }

    // Keep the launcher on screen when Back is pressed on the home screen
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) return true
        return super.onKeyDown(keyCode, event)
    }

    inner class AppAdapter(
        private val items: List<AppItem>,
        private val onFocus: (AppItem) -> Unit
    ) : RecyclerView.Adapter<AppAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val icon: ImageView = v.findViewById(R.id.icon)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_app, p, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val app = items[pos]
            h.icon.setImageDrawable(app.image)
            h.itemView.setOnFocusChangeListener { v, has ->
                v.animate().scaleX(if (has) 1.12f else 1f).scaleY(if (has) 1.12f else 1f)
                    .setDuration(120).start()
                if (has) { v.elevation = 12f; onFocus(app) } else v.elevation = 0f
            }
            h.itemView.setOnClickListener {
                try { startActivity(app.intent) } catch (e: Exception) { /* app not launchable */ }
            }
        }
    }
}
