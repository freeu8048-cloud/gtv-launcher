package com.example.gtvlauncher

import android.animation.ValueAnimator
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.TransitionDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Collections
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

private const val HOUR = 3_600_000L
private const val IMG = "https://image.tmdb.org/t/p/"

class MainActivity : AppCompatActivity() {
    private lateinit var store: Store
    private lateinit var root: FrameLayout
    private lateinit var scrimLeft: View
    private lateinit var scrimBottom: View
    private lateinit var tabsRow: LinearLayout
    private lateinit var weather: TextView
    private lateinit var clock: TextView
    private lateinit var greeting: TextView
    private lateinit var hero: LinearLayout
    private lateinit var heroEyebrow: TextView
    private lateinit var heroTitle: TextView
    private lateinit var heroMeta: TextView
    private lateinit var heroSub: TextView
    private lateinit var heroButtons: LinearLayout
    private lateinit var heroListBtn: TextView
    private lateinit var backdrop: ImageView
    private lateinit var searchPage: LinearLayout
    private lateinit var searchBox: EditText
    private lateinit var searchStatus: TextView
    private lateinit var searchApps: RecyclerView
    private lateinit var searchGrid: RecyclerView
    private lateinit var homePage: ScrollView
    private lateinit var appRow: RecyclerView
    private lateinit var homeRows: LinearLayout
    private lateinit var moviesPage: ScrollView
    private lateinit var moviesRows: LinearLayout
    private lateinit var showsPage: ScrollView
    private lateinit var showsRows: LinearLayout
    private lateinit var appsGrid: RecyclerView
    private lateinit var libraryPage: ScrollView
    private lateinit var libraryRows: LinearLayout
    private lateinit var settingsGrid: RecyclerView
    private lateinit var ssLayout: FrameLayout
    private lateinit var ssA: ImageView
    private lateinit var ssB: ImageView
    private lateinit var ssClock: TextView
    private lateinit var ssInfo: TextView
    private lateinit var pages: List<View>

    private val handler = Handler(Looper.getMainLooper())
    private val tabNames = listOf("Search", "Watch Now", "Movies", "TV Shows", "Apps", "Library", "Settings")
    private val tabViews = ArrayList<TextView>()
    private var page = 1
    private var accent = Color.WHITE
    private var currentBg: Drawable? = null

    private var allApps: List<AppItem> = emptyList()
    private var lastSig = ""
    private var currentCtx = ""
    private var ctxRunnable: Runnable? = null
    private var searchRunnable: Runnable? = null
    private var searchToken = 0
    private var pendingFocusPkg: String? = null

    private var shelfTitles: List<Title> = emptyList()
    private var shelfIdx = 0
    private var shelfEyebrow = "TRENDING"
    private var currentHeroTitle: Title? = null
    private var posterFocused = false
    private var weatherText = ""

    private var ssPaths: List<String> = emptyList()
    private var ssIdx = 0
    private var ssFront = false

    private val priority = listOf(
        "com.netflix.ninja", "com.google.android.youtube.tv", "com.amazon.firetv.youtube",
        "com.amazon.amazonvideo.livingroom", "in.startv.hotstar", "com.sonyliv",
        "com.graymatrix.did", "com.mxtech.videoplayer.ad", "org.videolan.vlc"
    )
    private val junkLabels = listOf("game center", "amazon kids", "amazon live", "minitv", "live shopping")
    private val idleOptions = listOf(0, 1, 2, 5, 10)

    private val tick = object : Runnable {
        override fun run() {
            val pattern = if (store.clock24) "HH:mm" else "h:mm a"
            clock.text = SimpleDateFormat(pattern, Locale.getDefault()).format(Date())
            val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val part = when {
                h < 12 -> "Good morning"
                h < 17 -> "Good afternoon"
                else -> "Good evening"
            }
            val name = store.profile
            greeting.text = part + (if (name.isNotEmpty()) ", " + name else "") + "   •   " +
                SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())
            handler.postDelayed(this, 30_000)
        }
    }

    // Top shelf: rotate featured titles while the user is on the dock / tabs
    private val shelfTick = object : Runnable {
        override fun run() {
            if (page == 1 && !posterFocused && shelfTitles.isNotEmpty() && !store.reduceMotion &&
                ssLayout.visibility != View.VISIBLE && heroButtons.focusedChild == null) {
                shelfIdx = (shelfIdx + 1) % shelfTitles.size
                showTitleHero(shelfTitles[shelfIdx], shelfEyebrow)
            }
            handler.postDelayed(this, 7000)
        }
    }

    private val idleRunnable = Runnable { startScreensaver() }
    private val ssRunnable = Runnable { ssStep() }

    // =====================================================================
    // Lifecycle
    // =====================================================================
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = Store(this)
        Tmdb.key = getString(R.string.tmdb_key).trim()
        bindViews()
        buildTabs()
        setupLists()
        applyTheme(false)
        showPage(1, false)
        loadWeather()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(tick)
        handler.removeCallbacks(shelfTick)
        handler.post(tick)
        handler.postDelayed(shelfTick, 7000)
        reloadApps(false)
        if (page == 5) buildLibrary()
        resetIdle()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
        handler.removeCallbacks(shelfTick)
        handler.removeCallbacks(idleRunnable)
        stopScreensaver()
    }

    private fun bindViews() {
        root = findViewById(R.id.root)
        scrimLeft = findViewById(R.id.scrimLeft)
        scrimBottom = findViewById(R.id.scrimBottom)
        tabsRow = findViewById(R.id.tabsRow)
        weather = findViewById(R.id.weather)
        clock = findViewById(R.id.clock)
        greeting = findViewById(R.id.greeting)
        hero = findViewById(R.id.hero)
        heroEyebrow = findViewById(R.id.heroEyebrow)
        heroTitle = findViewById(R.id.heroTitle)
        heroMeta = findViewById(R.id.heroMeta)
        heroSub = findViewById(R.id.heroSub)
        heroButtons = findViewById(R.id.heroButtons)
        backdrop = findViewById(R.id.backdrop)
        searchPage = findViewById(R.id.searchPage)
        searchBox = findViewById(R.id.searchBox)
        searchStatus = findViewById(R.id.searchStatus)
        searchApps = findViewById(R.id.searchApps)
        searchGrid = findViewById(R.id.searchGrid)
        homePage = findViewById(R.id.homePage)
        appRow = findViewById(R.id.appRow)
        homeRows = findViewById(R.id.homeRows)
        moviesPage = findViewById(R.id.moviesPage)
        moviesRows = findViewById(R.id.moviesRows)
        showsPage = findViewById(R.id.showsPage)
        showsRows = findViewById(R.id.showsRows)
        appsGrid = findViewById(R.id.appsGrid)
        libraryPage = findViewById(R.id.libraryPage)
        libraryRows = findViewById(R.id.libraryRows)
        settingsGrid = findViewById(R.id.settingsGrid)
        ssLayout = findViewById(R.id.screensaver)
        ssA = findViewById(R.id.ssA)
        ssB = findViewById(R.id.ssB)
        ssClock = findViewById(R.id.ssClock)
        ssInfo = findViewById(R.id.ssInfo)
        pages = listOf(searchPage, homePage, moviesPage, showsPage, appsGrid, libraryPage, settingsGrid)
    }

    private fun setupLists() {
        appRow.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        searchApps.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        appsGrid.layoutManager = GridLayoutManager(this, 6)
        settingsGrid.layoutManager = GridLayoutManager(this, 6)
        settingsGrid.itemAnimator = null
        searchGrid.layoutManager = GridLayoutManager(this, 4)

        searchBox.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                doSearch(v.text.toString().trim())
                true
            } else {
                false
            }
        }
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                searchRunnable?.let { handler.removeCallbacks(it) }
                val q = s?.toString()?.trim() ?: ""
                val r = Runnable { doSearch(q) }
                searchRunnable = r
                handler.postDelayed(r, 700)
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    // =====================================================================
    // Tab bar (floating glass pill) & pages
    // =====================================================================
    private fun buildTabs() {
        tabsRow.background = roundBg(this, Color.parseColor("#33FFFFFF"), 24)
        tabsRow.setPadding(dpi(4), dpi(3), dpi(4), dpi(3))
        for ((i, name) in tabNames.withIndex()) {
            val tv = TextView(this)
            tv.text = name
            tv.textSize = 14f
            tv.isFocusable = false
            tv.isClickable = true
            tv.setPadding(dpi(12), dpi(6), dpi(12), dpi(6))
            tv.setOnFocusChangeListener { _, has ->
                if (has) showPage(i, true)
                styleTab(i, has)
            }
            tv.setOnClickListener {
                showPage(i, true)
                pages[page].requestFocus()
            }
            tabsRow.addView(tv, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            tabViews.add(tv)
        }
    }

    private fun styleTab(i: Int, focused: Boolean) {
        val tv = tabViews[i]
        val sel = i == page
        if (focused) {
            tv.setTextColor(Color.parseColor("#101010"))
            tv.background = roundBg(this, accent, 18)
        } else {
            tv.setTextColor(if (sel) Color.WHITE else Color.parseColor("#B0B8CC"))
            tv.background = if (sel) roundBg(this, Color.parseColor("#40FFFFFF"), 18) else null
        }
        tv.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun updateTabs() {
        for (i in tabViews.indices) styleTab(i, tabViews[i].hasFocus())
    }

    private fun showPage(i: Int, animate: Boolean) {
        if (i == page && pages[i].visibility == View.VISIBLE) {
            updateTabs()
            return
        }
        page = i
        posterFocused = false
        for ((k, v) in pages.withIndex()) v.visibility = if (k == i) View.VISIBLE else View.GONE
        hero.visibility = if (i == 1 || i == 2 || i == 3 || i == 5) View.VISIBLE else View.GONE
        updateTabs()
        setBackdrop(null)
        currentHeroTitle = null
        heroButtons.visibility = View.GONE
        heroMeta.text = ""
        heroEyebrow.text = ""
        when (i) {
            2 -> { heroTitle.text = "Movies"; heroSub.text = "Popular, new and top picks by genre" }
            3 -> { heroTitle.text = "TV Shows"; heroSub.text = "Popular series and shows by genre" }
            5 -> { heroTitle.text = "Library"; heroSub.text = "Your recent apps and Up Next" }
            else -> { }
        }
        if (animate && !store.reduceMotion) {
            val v = pages[i]
            v.alpha = 0f
            v.translationY = dpi(14).toFloat()
            v.animate().alpha(1f).translationY(0f).setDuration(260)
                .setInterpolator(DecelerateInterpolator()).start()
        }
        when (i) {
            2 -> loadCatalog("movie")
            3 -> loadCatalog("tv")
            4 -> showAppsGrid()
            5 -> buildLibrary()
            6 -> buildSettings()
            else -> { }
        }
    }

    private fun focusHomeApp() {
        appRow.getChildAt(0)?.requestFocus()
        handler.postDelayed({
            if (page == 1 && appRow.focusedChild == null) appRow.getChildAt(0)?.requestFocus()
            for (tv in tabViews) tv.isFocusable = true
        }, 300)
    }

    private fun focusHomeAt(idx: Int) {
        appRow.scrollToPosition(idx)
        handler.postDelayed({
            val vh = appRow.findViewHolderForAdapterPosition(idx)
            if (vh != null) vh.itemView.requestFocus() else appRow.getChildAt(0)?.requestFocus()
            for (tv in tabViews) tv.isFocusable = true
        }, 150)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (ssLayout.visibility == View.VISIBLE) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                stopScreensaver()
                resetIdle()
            }
            return true
        }
        resetIdle()
        if (event.action == KeyEvent.ACTION_DOWN && event.keyCode == KeyEvent.KEYCODE_MENU) {
            showControlCenter()
            return true
        }
        if (event.action == KeyEvent.ACTION_DOWN && event.keyCode == KeyEvent.KEYCODE_DPAD_UP) {
            val f = currentFocus
            if (f != null && !tabViews.contains(f)) {
                val next = f.focusSearch(View.FOCUS_UP)
                if (next != null && tabViews.contains(next)) {
                    tabViews[page].requestFocus()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (page != 1) {
                showPage(1, true)
            } else {
                homePage.smoothScrollTo(0, 0)
            }
            focusHomeApp()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // =====================================================================
    // Theme
    // =====================================================================
    private fun applyTheme(animate: Boolean) {
        val t = Themes.current(store)
        accent = Color.parseColor(t.accent)
        val bg = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor(t.c1), Color.parseColor(t.c2), Color.parseColor(t.c3)))
        val old = currentBg
        if (animate && old != null) {
            val td = TransitionDrawable(arrayOf<Drawable>(old, bg))
            root.background = td
            td.startTransition(450)
        } else {
            root.background = bg
        }
        currentBg = bg
        val s = Color.parseColor(t.scrim)
        scrimLeft.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(withAlpha(s, 0xF2), withAlpha(s, 0x99), withAlpha(s, 0x00)))
        scrimBottom.background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
            intArrayOf(withAlpha(s, 0xFF), withAlpha(s, 0x00)))
        buildHeroButtons()
        recolor(root)
        updateTabs()
    }

    private fun recolor(v: View) {
        val tag = v.tag
        if (tag == "ringO") v.background = ringDrawable(this, true, accent)
        if (tag == "ringR") v.background = ringDrawable(this, false, accent)
        if (tag == "ringA") v.background = ringDrawable(this, false, accent, 17)
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) recolor(v.getChildAt(i))
        }
    }

    private fun cycleTheme() {
        store.theme = (store.theme + 1) % Themes.all.size
        applyTheme(true)
        Toast.makeText(this, "Theme: " + Themes.all[store.theme].name, Toast.LENGTH_SHORT).show()
    }

    // =====================================================================
    // Animations & top shelf hero
    // =====================================================================
    private fun enter(v: View, index: Int, step: Int) {
        v.animate().cancel()
        if (store.reduceMotion) {
            v.alpha = 1f
            v.translationY = 0f
            return
        }
        v.alpha = 0f
        v.translationY = dpi(22).toFloat()
        v.animate().alpha(1f).translationY(0f).setStartDelay((index * step).toLong())
            .setDuration(380).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun playShine(shine: View, host: View) {
        if (store.reduceMotion) return
        val w = if (host.width > 0) host.width.toFloat() else dpi(208).toFloat()
        shine.animate().cancel()
        shine.translationX = -dpi(100).toFloat()
        shine.alpha = 1f
        shine.animate().translationX(w + dpi(10).toFloat()).setStartDelay(0).setDuration(650)
            .withEndAction { shine.alpha = 0f }.start()
    }

    private fun swapHero(apply: () -> Unit) {
        val views = listOf(heroEyebrow, heroTitle, heroMeta, heroSub)
        if (store.reduceMotion) {
            apply()
            return
        }
        for (v in views) {
            v.animate().cancel()
            v.alpha = 0f
            v.translationY = dpi(10).toFloat()
        }
        apply()
        for ((i, v) in views.withIndex()) {
            v.animate().alpha(1f).translationY(0f).setStartDelay((i * 40).toLong())
                .setDuration(220).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun buildHeroButtons() {
        heroButtons.removeAllViews()
        val lp1 = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp1.setMargins(0, 0, dpi(10), 0)
        heroButtons.addView(pill(this, "▶  Details", accent) {
            val t = currentHeroTitle
            if (t != null) openDetail(t)
        }, lp1)
        heroListBtn = pill(this, "＋  Up Next", accent) { toggleUpNext() }
        heroButtons.addView(heroListBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        updateHeroListBtn()
    }

    private fun updateHeroListBtn() {
        val t = currentHeroTitle
        if (t != null) heroListBtn.text = if (store.inList(t)) "✓  In Up Next" else "＋  Up Next"
    }

    private fun toggleUpNext() {
        val t = currentHeroTitle ?: return
        val added = store.toggleList(t)
        updateHeroListBtn()
        Toast.makeText(this, if (added) "Added to Up Next" else "Removed from Up Next",
            Toast.LENGTH_SHORT).show()
    }

    private fun showAppHero(app: AppItem) {
        currentHeroTitle = null
        heroButtons.visibility = View.GONE
        swapHero {
            heroEyebrow.text = "APP"
            heroTitle.text = app.label
            heroMeta.text = ""
            heroSub.text = "Press OK to open  •  Hold OK to move, hide or uninstall"
        }
        setBackdrop(null)
    }

    private fun showTitleHero(t: Title, eyebrow: String) {
        currentHeroTitle = t
        swapHero {
            heroEyebrow.text = eyebrow
            heroTitle.text = t.name
            heroMeta.text = "★ %.1f   •   %s   •   %s".format(t.rating, t.year, t.kind)
            heroSub.text = t.overview
        }
        heroButtons.visibility = View.VISIBLE
        updateHeroListBtn()
        setBackdrop(t.image)
    }

    private fun setBackdrop(path: String?) {
        backdrop.animate().cancel()
        backdrop.scaleX = 1f
        backdrop.scaleY = 1f
        if (path == null || path.isEmpty()) {
            Glide.with(this).clear(backdrop)
            backdrop.setImageDrawable(null)
        } else {
            Glide.with(this).load(IMG + "w1280" + path)
                .transition(DrawableTransitionOptions.withCrossFade(250)).into(backdrop)
            if (!store.reduceMotion) {
                backdrop.animate().scaleX(1.08f).scaleY(1.08f).setStartDelay(0)
                    .setDuration(14000).setInterpolator(LinearInterpolator()).start()
            }
        }
    }

    // =====================================================================
    // Screensaver (ambient photos) & Control Center
    // =====================================================================
    private fun resetIdle() {
        handler.removeCallbacks(idleRunnable)
        val m = store.idleMinutes
        if (m > 0 && ssLayout.visibility != View.VISIBLE) {
            handler.postDelayed(idleRunnable, m * 60_000L)
        }
    }

    private fun startScreensaver() {
        if (ssLayout.visibility == View.VISIBLE) return
        val paths = ArrayList<String>()
        val c = store.cacheGetAny("ctx_default")
        if (c != null) {
            for (r in rowsFromJson(c)) {
                for (t in r.items) if (t.backdrop.isNotEmpty()) paths.add(t.backdrop)
            }
        }
        Collections.shuffle(paths)
        ssPaths = paths.take(24)
        ssIdx = 0
        ssFront = false
        ssA.alpha = 0f
        ssB.alpha = 0f
        ssLayout.alpha = 0f
        ssLayout.visibility = View.VISIBLE
        ssLayout.animate().alpha(1f).setDuration(700).start()
        ssStep()
    }

    private fun ssStep() {
        if (ssLayout.visibility != View.VISIBLE) return
        val pattern = if (store.clock24) "HH:mm" else "h:mm"
        ssClock.text = SimpleDateFormat(pattern, Locale.getDefault()).format(Date())
        ssInfo.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()) +
            (if (weatherText.isNotEmpty()) "   •   " + weatherText else "")
        if (ssPaths.isNotEmpty()) {
            val next = if (ssFront) ssB else ssA
            val prev = if (ssFront) ssA else ssB
            ssFront = !ssFront
            val path = ssPaths[ssIdx % ssPaths.size]
            ssIdx++
            next.scaleX = 1f
            next.scaleY = 1f
            Glide.with(this).load(IMG + "w1280" + path).into(next)
            next.animate().alpha(1f).setDuration(1500).start()
            prev.animate().alpha(0f).setDuration(1500).start()
            val va = ValueAnimator.ofFloat(1f, 1.12f)
            va.duration = 10000
            va.addUpdateListener {
                val f = it.animatedValue as Float
                next.scaleX = f
                next.scaleY = f
            }
            va.start()
        }
        handler.postDelayed(ssRunnable, 9000)
    }

    private fun stopScreensaver() {
        handler.removeCallbacks(ssRunnable)
        if (ssLayout.visibility == View.VISIBLE) {
            ssLayout.animate().cancel()
            ssLayout.visibility = View.GONE
        }
    }

    private fun showControlCenter() {
        val d = Dialog(this, android.R.style.Theme_Translucent_NoTitleBar)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = roundBg(this, Color.parseColor("#F01C1C1E"), 26)
        box.setPadding(dpi(28), dpi(22), dpi(28), dpi(24))

        val title = TextView(this)
        title.text = "Control Center"
        title.setTextColor(Color.WHITE)
        title.textSize = 20f
        title.typeface = Typeface.DEFAULT_BOLD
        box.addView(title)

        val sub = TextView(this)
        sub.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()) +
            (if (weatherText.isNotEmpty()) "   •   " + weatherText else "")
        sub.setTextColor(Color.parseColor("#B8C0D6"))
        sub.textSize = 13f
        box.addView(sub)

        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        val r1lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        r1lp.topMargin = dpi(16)
        val r2lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        r2lp.topMargin = dpi(10)
        box.addView(row1, r1lp)
        box.addView(row2, r2lp)

        fun add(row: LinearLayout, text: String, action: () -> Unit): TextView {
            val p = pill(this, text, accent) {
                d.dismiss()
                action()
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 0, dpi(10), 0)
            row.addView(p, lp)
            return p
        }

        val first = add(row1, "🎨  Theme") { cycleTheme() }
        add(row1, "🌙  Screensaver") { startScreensaver() }
        add(row1, "📶  Wi-Fi") { openSystem(Settings.ACTION_WIFI_SETTINGS) }
        add(row1, "🎧  Bluetooth") { openSystem(Settings.ACTION_BLUETOOTH_SETTINGS) }
        add(row2, "🖥  Display") { openSystem(Settings.ACTION_DISPLAY_SETTINGS) }
        add(row2, "🔊  Sound") { openSystem(Settings.ACTION_SOUND_SETTINGS) }
        add(row2, "⚙  Settings") { openSystem(Settings.ACTION_SETTINGS) }
        add(row2, if (store.reduceMotion) "🎞  Motion: reduced" else "🎞  Motion: full") {
            store.reduceMotion = !store.reduceMotion
        }

        d.setContentView(box, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        d.window?.setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        d.window?.setGravity(Gravity.CENTER)
        d.window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        d.window?.setDimAmount(0.55f)
        d.show()
        first.requestFocus()
    }

    // =====================================================================
    // Apps (dock)
    // =====================================================================
    private fun loadAllApps(): List<AppItem> {
        val pm = packageManager
        val seen = HashSet<String>()
        val all = ArrayList<AppItem>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || !seen.add(pkg)) continue
                val banner: Drawable? = ri.activityInfo.loadBanner(pm)
                    ?: ri.activityInfo.applicationInfo.loadBanner(pm)
                if (banner != null) {
                    all.add(AppItem(pkg, ri.loadLabel(pm).toString(), banner, true))
                } else {
                    all.add(AppItem(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm), false))
                }
            }
        }
        return all
    }

    private fun effectiveHidden(): Set<String> {
        if (!store.hasHidden()) {
            val d = allApps.filter { a -> junkLabels.any { a.label.lowercase().contains(it) } }
                .map { it.pkg }.toSet()
            store.setHidden(d)
            return d
        }
        return store.hidden()
    }

    private fun sortApps(list: List<AppItem>): List<AppItem> {
        val order = store.order()
        return list.sortedWith(compareBy<AppItem>(
            { val o = order.indexOf(it.pkg); if (o >= 0) o else 9999 },
            { -store.launchCount(it.pkg) },
            { val q = priority.indexOf(it.pkg); if (q >= 0) q else 9999 },
            { it.label.lowercase() }
        ))
    }

    private fun reloadApps(force: Boolean) {
        allApps = loadAllApps()
        val hidden = effectiveHidden()
        val sorted = sortApps(allApps.filter { it.pkg !in hidden })
        val sig = sorted.joinToString("|") { it.pkg }
        if (force || sig != lastSig) {
            lastSig = sig
            appRow.adapter = AppAdapter(sorted, R.layout.item_app, true)
            if (page == 1) {
                val fp = pendingFocusPkg
                pendingFocusPkg = null
                val idx = if (fp != null) sorted.indexOfFirst { it.pkg == fp } else -1
                if (idx >= 0) focusHomeAt(idx) else focusHomeApp()
            }
            if (page == 4) showAppsGrid()
        }
    }

    private fun showAppsGrid() {
        val hidden = effectiveHidden()
        val list = ArrayList<AppItem>()
        for (a in allApps.sortedBy { it.label.lowercase() }) {
            if (a.pkg in hidden) {
                if (store.showHidden) list.add(a.copy(label = a.label + " (hidden)"))
            } else {
                list.add(a)
            }
        }
        appsGrid.adapter = AppAdapter(list, R.layout.item_app_grid, false)
    }

    private fun launchApp(app: AppItem) {
        if (!launchPackage(this, app.pkg, store))
            Toast.makeText(this, "Can't open " + app.label, Toast.LENGTH_SHORT).show()
    }

    private fun moveApp(app: AppItem, delta: Int) {
        val hidden = effectiveHidden()
        val cur = sortApps(allApps.filter { it.pkg !in hidden }).map { it.pkg }.toMutableList()
        val i = cur.indexOf(app.pkg)
        if (i < 0) return
        val j = if (delta == 0) 0 else (i + delta).coerceIn(0, cur.size - 1)
        cur.removeAt(i)
        cur.add(j, app.pkg)
        store.setOrder(cur)
        pendingFocusPkg = app.pkg
        reloadApps(true)
    }

    private fun showAppOptions(app: AppItem) {
        val hidden = store.hidden()
        val isHidden = app.pkg in hidden
        val options = arrayOf(
            "Move to front", "Move left", "Move right",
            if (isHidden) "Unhide" else "Hide this app",
            "App info", "Uninstall", "Cancel"
        )
        AlertDialog.Builder(this).setTitle(app.label.removeSuffix(" (hidden)"))
            .setItems(options) { _, which ->
                when (which) {
                    0 -> moveApp(app, 0)
                    1 -> moveApp(app, -1)
                    2 -> moveApp(app, 1)
                    3 -> {
                        if (isHidden) hidden.remove(app.pkg) else hidden.add(app.pkg)
                        store.setHidden(hidden)
                        reloadApps(true)
                    }
                    4 -> openIntent(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + app.pkg)))
                    5 -> openIntent(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.pkg)))
                    else -> { }
                }
            }.show()
    }

    private fun openIntent(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Not available on this device", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openSystem(action: String) {
        openIntent(Intent(action))
    }

    // =====================================================================
    // Watch Now: app-specific content ("top shelf")
    // =====================================================================
    private fun hasKey(): Boolean = Tmdb.key.isNotEmpty() && !Tmdb.key.startsWith("PASTE")

    private fun ctxKeyOf(prov: Provider?): String = if (prov != null) prov.id.toString() else "default"

    private fun onHomeAppFocused(app: AppItem) {
        val prov = Tmdb.providerByPackage(app.pkg)
        shelfEyebrow = if (prov != null) "ON " + prov.name.uppercase() else "TRENDING"
        if (ctxKeyOf(prov) == currentCtx && shelfTitles.isNotEmpty()) {
            showTitleHero(shelfTitles[shelfIdx % shelfTitles.size], shelfEyebrow)
        } else {
            showAppHero(app)
        }
        ctxRunnable?.let { handler.removeCallbacks(it) }
        val r = Runnable { loadHomeContext(prov) }
        ctxRunnable = r
        handler.postDelayed(r, 450)
    }

    private fun setShelf(rows: List<ContentRow>) {
        val first = rows.firstOrNull()
        shelfTitles = if (first != null) first.items.take(8) else emptyList()
        shelfIdx = 0
        if (page == 1 && !posterFocused && shelfTitles.isNotEmpty() && heroButtons.focusedChild == null) {
            showTitleHero(shelfTitles[0], shelfEyebrow)
        }
    }

    private fun loadHomeContext(prov: Provider?) {
        val ctx = ctxKeyOf(prov)
        if (ctx == currentCtx && homeRows.childCount > 0) return
        currentCtx = ctx
        shelfEyebrow = if (prov != null) "ON " + prov.name.uppercase() else "TRENDING"
        val ck = "ctx_" + ctx
        val cached = store.cacheGet(ck, 6 * HOUR)
        if (cached != null) {
            val rows = rowsFromJson(cached)
            renderRows(homeRows, rows, prov == null)
            setShelf(rows)
            return
        }
        homeRows.removeAllViews()
        shelfTitles = emptyList()
        if (!hasKey()) {
            addNotice(homeRows, "Add your free TMDB key to see content here.")
            return
        }
        addNotice(homeRows, "Loading…")
        thread {
            var rows = if (prov != null) Tmdb.providerRows(prov) else Tmdb.homeRows()
            if (rows.isEmpty() && prov != null) rows = Tmdb.homeRows()
            if (rows.isNotEmpty()) store.cachePut(ck, rowsToJson(rows))
            val result = rows
            runOnUiThread {
                if (currentCtx == ctx) {
                    if (result.isNotEmpty()) {
                        renderRows(homeRows, result, prov == null)
                        setShelf(result)
                    } else {
                        homeRows.removeAllViews()
                        addNotice(homeRows, "Couldn't load content. Check your internet connection.")
                    }
                }
            }
        }
    }

    private fun loadCatalog(type: String) {
        val container = if (type == "movie") moviesRows else showsRows
        if (container.childCount > 0) return
        val ck = "cat_" + type
        val cached = store.cacheGet(ck, 12 * HOUR)
        if (cached != null) {
            renderRows(container, rowsFromJson(cached), false)
            return
        }
        if (!hasKey()) {
            addNotice(container, "Add your free TMDB key to see content here.")
            return
        }
        addNotice(container, "Loading…")
        thread {
            val rows = Tmdb.catalogRows(type)
            if (rows.isNotEmpty()) store.cachePut(ck, rowsToJson(rows))
            runOnUiThread {
                container.removeAllViews()
                if (rows.isNotEmpty()) renderRows(container, rows, false)
                else addNotice(container, "Couldn't load content. Check your internet connection.")
            }
        }
    }

    // =====================================================================
    // Library
    // =====================================================================
    private fun buildLibrary() {
        libraryRows.removeAllViews()
        var idx = 0
        val recentApps = store.recents().mapNotNull { pkg -> allApps.firstOrNull { it.pkg == pkg } }
        if (recentApps.isNotEmpty()) {
            val label = sectionLabel("Recently opened")
            val rv = hRecycler()
            rv.adapter = AppAdapter(recentApps, R.layout.item_app, false)
            libraryRows.addView(label)
            libraryRows.addView(rv, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            enter(label, idx, 90)
            enter(rv, idx, 90)
            idx++
        }
        val list = store.myList()
        if (list.isNotEmpty()) addRow(libraryRows, ContentRow("Up Next", list), idx++)
        if (idx == 0) {
            addNotice(libraryRows,
                "Nothing here yet. Open apps from the launcher and add titles to Up Next " +
                    "(hold OK on any poster, or use the details screen).")
        }
    }

    // =====================================================================
    // Search (apps + movies + shows)
    // =====================================================================
    private fun doSearch(q: String) {
        val matches = if (q.isNotEmpty()) allApps.filter { it.label.contains(q, true) } else emptyList()
        searchApps.adapter = AppAdapter(matches, R.layout.item_app, false)
        searchApps.visibility = if (matches.isEmpty()) View.GONE else View.VISIBLE
        if (q.isEmpty()) {
            searchGrid.adapter = null
            searchStatus.text = ""
            return
        }
        if (q.length < 2) return
        if (!hasKey()) {
            searchStatus.text = "Add your free TMDB key to search movies and shows."
            return
        }
        val token = ++searchToken
        searchStatus.text = "Searching…"
        thread {
            val r = Tmdb.search(q)
            runOnUiThread {
                if (token == searchToken) {
                    searchGrid.adapter = PosterAdapter(r, R.layout.item_poster_grid)
                    searchStatus.text = if (r.isEmpty()) "No movies or shows found for \"" + q + "\"" else ""
                }
            }
        }
    }

    // =====================================================================
    // Settings page
    // =====================================================================
    private fun idleLabel(): String = if (store.idleMinutes == 0) "Off" else store.idleMinutes.toString() + " min"

    private fun askProfileName() {
        val input = EditText(this)
        input.setText(store.profile)
        input.setSingleLine(true)
        AlertDialog.Builder(this).setTitle("Your name")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                store.profile = input.text.toString().trim()
                handler.post(tick)
                rebuildSettingsKeepFocus()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun buildSettings() {
        val t = ArrayList<Tile>()
        fun sys(emoji: String, label: String, action: String) {
            t.add(Tile(emoji, label) { openSystem(action) })
        }
        sys("📶", "Wi-Fi", Settings.ACTION_WIFI_SETTINGS)
        sys("🎧", "Bluetooth", Settings.ACTION_BLUETOOTH_SETTINGS)
        sys("🖥", "Display", Settings.ACTION_DISPLAY_SETTINGS)
        sys("🔊", "Sound", Settings.ACTION_SOUND_SETTINGS)
        sys("🌐", "Network", Settings.ACTION_WIRELESS_SETTINGS)
        sys("🕒", "Date & time", Settings.ACTION_DATE_SETTINGS)
        sys("🈯", "Language", Settings.ACTION_LOCALE_SETTINGS)
        sys("⌨", "Keyboard", Settings.ACTION_INPUT_METHOD_SETTINGS)
        sys("📦", "Apps", Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS)
        sys("💾", "Storage", Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
        sys("♿", "Accessibility", Settings.ACTION_ACCESSIBILITY_SETTINGS)
        sys("ℹ", "About device", Settings.ACTION_DEVICE_INFO_SETTINGS)
        sys("🛠", "Developer", Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
        sys("⚙", "All settings", Settings.ACTION_SETTINGS)

        t.add(Tile("🎛", "Control Center") { showControlCenter() })
        t.add(Tile("🎨", "Theme: " + Themes.all[store.theme].name) {
            cycleTheme()
            rebuildSettingsKeepFocus()
        })
        t.add(Tile("👤", "Profile: " + (if (store.profile.isEmpty()) "Guest" else store.profile)) {
            askProfileName()
        })
        t.add(Tile("🌙", "Screensaver now") { startScreensaver() })
        t.add(Tile("⏱", "Screensaver: " + idleLabel()) {
            val i = idleOptions.indexOf(store.idleMinutes)
            store.idleMinutes = idleOptions[(i + 1) % idleOptions.size]
            resetIdle()
            rebuildSettingsKeepFocus()
        })
        t.add(Tile("🎞", if (store.reduceMotion) "Motion: reduced" else "Motion: full") {
            store.reduceMotion = !store.reduceMotion
            rebuildSettingsKeepFocus()
        })
        t.add(Tile(if (store.showHidden) "👁" else "🙈",
            if (store.showHidden) "Hidden apps: shown" else "Hidden apps: off") {
            store.showHidden = !store.showHidden
            rebuildSettingsKeepFocus()
        })
        t.add(Tile("🕐", if (store.clock24) "Clock: 24-hour" else "Clock: 12-hour") {
            store.clock24 = !store.clock24
            handler.post(tick)
            rebuildSettingsKeepFocus()
        })
        t.add(Tile("🔄", "Refresh content") {
            store.clearCache()
            homeRows.removeAllViews()
            moviesRows.removeAllViews()
            showsRows.removeAllViews()
            currentCtx = ""
            shelfTitles = emptyList()
            loadWeather()
            Toast.makeText(this, "Content will refresh", Toast.LENGTH_SHORT).show()
        })
        t.add(Tile("↩", "Reset layout") {
            store.resetLayout()
            lastSig = ""
            reloadApps(true)
            Toast.makeText(this, "Apps order reset", Toast.LENGTH_SHORT).show()
        })
        settingsGrid.adapter = TileAdapter(t)
    }

    private fun rebuildSettingsKeepFocus() {
        val f = settingsGrid.focusedChild
        val pos = if (f != null) settingsGrid.getChildAdapterPosition(f) else -1
        buildSettings()
        if (pos >= 0) {
            settingsGrid.post { settingsGrid.findViewHolderForAdapterPosition(pos)?.itemView?.requestFocus() }
        }
    }

    // =====================================================================
    // Weather
    // =====================================================================
    private fun loadWeather() {
        val c = store.cacheGet("weather", 30 * 60_000L)
        if (c != null) {
            weather.text = c
            weatherText = c
            return
        }
        thread {
            val w = Weather.fetch()
            if (w != null) {
                store.cachePut("weather", w)
                runOnUiThread {
                    weather.text = w
                    weatherText = w
                }
            }
        }
    }

    // =====================================================================
    // Row rendering helpers
    // =====================================================================
    private fun sectionLabel(text: String): TextView {
        val label = TextView(this)
        label.text = text
        label.setTextColor(Color.WHITE)
        label.textSize = 16f
        label.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        label.setPadding(0, dpi(12), 0, dpi(2))
        return label
    }

    private fun hRecycler(): RecyclerView {
        val rv = RecyclerView(this)
        rv.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rv.clipChildren = false
        rv.clipToPadding = false
        rv.setPadding(0, dpi(10), 0, dpi(10))
        return rv
    }

    private fun addNotice(container: LinearLayout, text: String) {
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(Color.parseColor("#C8CFE2"))
        tv.textSize = 14f
        tv.setPadding(0, dpi(16), 0, 0)
        container.addView(tv)
    }

    private fun addRow(container: LinearLayout, r: ContentRow, idx: Int) {
        val label = sectionLabel(r.title)
        val rv = hRecycler()
        rv.adapter = PosterAdapter(r.items, R.layout.item_poster)
        container.addView(label)
        container.addView(rv, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        enter(label, idx, 90)
        enter(rv, idx, 90)
    }

    private fun renderRows(container: LinearLayout, rows: List<ContentRow>, withMyList: Boolean) {
        container.removeAllViews()
        var idx = 0
        if (withMyList) {
            val l = store.myList()
            if (l.isNotEmpty()) addRow(container, ContentRow("Up Next", l), idx++)
        }
        for (r in rows) addRow(container, r, idx++)
        val credit = TextView(this)
        credit.text = "This product uses the TMDB API but is not endorsed or certified by TMDB."
        credit.setTextColor(Color.parseColor("#7F889F"))
        credit.textSize = 10f
        credit.setPadding(0, dpi(12), 0, 0)
        container.addView(credit)
    }

    private fun openDetail(t: Title) {
        startActivity(Intent(this, DetailActivity::class.java).putExtra("title", t.toJson().toString()))
    }

    // =====================================================================
    // Adapters
    // =====================================================================
    inner class AppAdapter(
        private val items: List<AppItem>,
        private val layoutRes: Int,
        private val isHome: Boolean
    ) : RecyclerView.Adapter<AppAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val icon: ImageView = v.findViewById(R.id.icon)
            val label: TextView = v.findViewById(R.id.label)
            val ring: View = v.findViewById(R.id.ring)
            val clip: View = v.findViewById(R.id.clip)
            val shine: View = v.findViewById(R.id.shine)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
            VH(LayoutInflater.from(p.context).inflate(layoutRes, p, false))

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val app = items[pos]
            h.icon.setImageDrawable(app.image)
            if (app.banner) {
                h.icon.scaleType = ImageView.ScaleType.CENTER_CROP
                h.icon.setPadding(0, 0, 0, 0)
            } else {
                h.icon.scaleType = ImageView.ScaleType.FIT_CENTER
                h.icon.setPadding(dpi(12), dpi(8), dpi(12), dpi(8))
            }
            h.clip.setClipToOutline(true)
            h.ring.background = ringDrawable(this@MainActivity, false, accent, 17)
            h.ring.tag = "ringA"
            h.label.text = app.label
            h.label.alpha = 0f
            enter(h.itemView, minOf(pos, 10), 45)
            h.itemView.setOnFocusChangeListener { v, has ->
                v.animate().setStartDelay(0).setInterpolator(OvershootInterpolator(1.6f))
                    .scaleX(if (has) 1.12f else 1f).scaleY(if (has) 1.12f else 1f)
                    .setDuration(180).start()
                h.label.animate().alpha(if (has) 1f else 0f).setDuration(150).start()
                if (has) {
                    playShine(h.shine, h.clip)
                    if (isHome) onHomeAppFocused(app) else showAppHero(app)
                }
            }
            h.itemView.setOnClickListener { launchApp(app) }
            h.itemView.setOnLongClickListener {
                showAppOptions(app)
                true
            }
        }
    }

    inner class PosterAdapter(
        private val items: List<Title>,
        private val layoutRes: Int
    ) : RecyclerView.Adapter<PosterAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val img: ImageView = v.findViewById(R.id.img)
            val clip: View = v.findViewById(R.id.clip)
            val shine: View = v.findViewById(R.id.shine)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
            VH(LayoutInflater.from(p.context).inflate(layoutRes, p, false))

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val t = items[pos]
            h.clip.setClipToOutline(true)
            h.itemView.background = ringDrawable(this@MainActivity, false, accent)
            h.itemView.tag = "ringR"
            Glide.with(h.img).load(IMG + "w500" + t.image).centerCrop().into(h.img)
            h.itemView.setOnFocusChangeListener { v, has ->
                v.animate().setStartDelay(0).setInterpolator(OvershootInterpolator(1.4f))
                    .scaleX(if (has) 1.08f else 1f).scaleY(if (has) 1.08f else 1f)
                    .setDuration(180).start()
                if (has) {
                    posterFocused = true
                    playShine(h.shine, h.clip)
                    showTitleHero(t, t.kind.uppercase())
                } else {
                    posterFocused = false
                }
            }
            h.itemView.setOnClickListener { openDetail(t) }
            h.itemView.setOnLongClickListener {
                val added = store.toggleList(t)
                Toast.makeText(this@MainActivity,
                    if (added) "Added to Up Next" else "Removed from Up Next",
                    Toast.LENGTH_SHORT).show()
                true
            }
        }
    }

    inner class TileAdapter(private val tiles: List<Tile>) :
        RecyclerView.Adapter<TileAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val emoji: TextView = v.findViewById(R.id.emoji)
            val label: TextView = v.findViewById(R.id.label)
            val ring: View = v.findViewById(R.id.ring)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_tile, p, false))

        override fun getItemCount(): Int = tiles.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val tile = tiles[pos]
            h.emoji.text = tile.emoji
            h.label.text = tile.label
            h.ring.background = ringDrawable(this@MainActivity, true, accent)
            h.ring.tag = "ringO"
            h.itemView.setOnFocusChangeListener { v, has ->
                v.animate().setStartDelay(0).setInterpolator(OvershootInterpolator(1.6f))
                    .scaleX(if (has) 1.12f else 1f).scaleY(if (has) 1.12f else 1f)
                    .setDuration(180).start()
                h.label.setTextColor(if (has) Color.WHITE else Color.parseColor("#B8C0D6"))
            }
            h.itemView.setOnClickListener { tile.action() }
        }
    }
}
