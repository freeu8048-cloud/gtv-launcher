package com.example.gtvlauncher

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.graphics.drawable.TransitionDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.thread

data class AppItem(val pkg: String, val label: String, val image: Drawable,
                   val intent: Intent?, val tint: Boolean = false)
data class Title(val name: String, val overview: String, val image: String,
                 val rating: Double, val year: String, val kind: String)
data class ContentRow(val title: String, val items: List<Title>,
                      val pkgs: List<String> = emptyList(), val appName: String = "")
class Theme(val name: String, val c1: String, val c2: String, val c3: String,
            val accent: String, val scrim: String)

private fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k, "")

class MainActivity : AppCompatActivity() {
    private lateinit var root: FrameLayout
    private lateinit var scrimLeft: View
    private lateinit var scrimBottom: View
    private lateinit var clock: TextView
    private lateinit var greeting: TextView
    private lateinit var heroTitle: TextView
    private lateinit var heroMeta: TextView
    private lateinit var heroSub: TextView
    private lateinit var backdrop: ImageView
    private lateinit var scroll: ScrollView
    private lateinit var appRow: RecyclerView
    private lateinit var rowsContainer: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("gtv", Context.MODE_PRIVATE) }
    private var accent = Color.WHITE
    private var currentBg: Drawable? = null

    private val themes = listOf(
        Theme("Midnight", "#1B2A49", "#10131C", "#07080C", "#FFFFFF", "#080B14"),
        Theme("Amoled Black", "#0A0A0A", "#000000", "#000000", "#FFFFFF", "#000000"),
        Theme("Sunset", "#4A1942", "#1E1033", "#0B0614", "#FFB86B", "#0B0614"),
        Theme("Forest", "#123524", "#0B1F16", "#050D09", "#7EE0A1", "#050D09"),
        Theme("Ocean", "#0B3C5D", "#0A1F33", "#050B14", "#5CC8FF", "#050B14"),
        Theme("Crimson", "#4A1218", "#1F0A0D", "#0A0405", "#FF6B6B", "#0A0405")
    )

    private val priority = listOf(
        "com.netflix.ninja", "com.google.android.youtube.tv",
        "com.amazon.amazonvideo.livingroom", "in.startv.hotstar",
        "com.jio.media.ondemand", "com.sonyliv", "com.graymatrix.did",
        "com.mxtech.videoplayer.ad", "org.videolan.vlc"
    )
    private val junkLabels = listOf("game center", "amazon kids", "amazon live", "minitv", "live shopping")

    private val providers = listOf(
        Triple("Netflix", 8, listOf("com.netflix.ninja")),
        Triple("Prime Video", 119, listOf("com.amazon.amazonvideo.livingroom")),
        Triple("Hotstar", 122, listOf("in.startv.hotstar", "in.startv.hotstar.dplus.tv", "in.startv.hotstar.dplus")),
        Triple("ZEE5", 232, listOf("com.graymatrix.did")),
        Triple("SonyLIV", 237, listOf("com.sonyliv"))
    )

    private val tick = object : Runnable {
        override fun run() {
            clock.text = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val part = when { h < 12 -> "Good morning"; h < 17 -> "Good afternoon"; else -> "Good evening" }
            greeting.text = part + "   •   " + SimpleDateFormat("EEEE, d MMM", Locale.getDefault()).format(Date())
            handler.postDelayed(this, 30_000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun withAlpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        root = findViewById(R.id.root)
        scrimLeft = findViewById(R.id.scrimLeft)
        scrimBottom = findViewById(R.id.scrimBottom)
        clock = findViewById(R.id.clock)
        greeting = findViewById(R.id.greeting)
        heroTitle = findViewById(R.id.heroTitle)
        heroMeta = findViewById(R.id.heroMeta)
        heroSub = findViewById(R.id.heroSub)
        backdrop = findViewById(R.id.backdrop)
        scroll = findViewById(R.id.scroll)
        appRow = findViewById(R.id.appRow)
        rowsContainer = findViewById(R.id.rowsContainer)
        appRow.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        applyTheme(false)
        loadContent()
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
        refresh()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    // ---------- Themes ----------
    private fun ring(oval: Boolean, color: Int): StateListDrawable {
        val focused = GradientDrawable()
        val normal = GradientDrawable()
        for (g in listOf(focused, normal)) {
            if (oval) g.shape = GradientDrawable.OVAL
            else { g.shape = GradientDrawable.RECTANGLE; g.cornerRadius = dp(12).toFloat() }
            g.setColor(Color.TRANSPARENT)
        }
        focused.setStroke(dp(3), color)
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_focused), focused)
        sl.addState(intArrayOf(), normal)
        return sl
    }

    private fun applyTheme(animate: Boolean) {
        val t = themes[prefs.getInt("theme", 0).coerceIn(0, themes.size - 1)]
        accent = Color.parseColor(t.accent)
        val bg = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor(t.c1), Color.parseColor(t.c2), Color.parseColor(t.c3)))
        val old = currentBg
        if (animate && old != null) {
            val td = TransitionDrawable(arrayOf<Drawable>(old, bg))
            root.background = td
            td.startTransition(450)
        } else {
            root.background = bg
        }
        currentBg = bg
        val s = Color.parseColor(t.scrim)
        scrimLeft.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(withAlpha(s, 0xF2), withAlpha(s, 0x99), withAlpha(s, 0x00)))
        scrimBottom.background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
            intArrayOf(withAlpha(s, 0xFF), withAlpha(s, 0x00)))
        recolor()
    }

    private fun recolor() {
        for (i in 0 until appRow.childCount) {
            appRow.getChildAt(i).findViewById<View>(R.id.ring)?.background = ring(true, accent)
        }
        for (i in 0 until rowsContainer.childCount) {
            val v = rowsContainer.getChildAt(i)
            if (v is RecyclerView) {
                for (j in 0 until v.childCount) v.getChildAt(j).background = ring(false, accent)
            }
        }
    }

    private fun cycleTheme() {
        val next = (prefs.getInt("theme", 0) + 1) % themes.size
        prefs.edit().putInt("theme", next).apply()
        applyTheme(true)
        Toast.makeText(this, "Theme: " + themes[next].name, Toast.LENGTH_SHORT).show()
    }

    // ---------- Animations ----------
    private fun enter(v: View, index: Int, step: Int) {
        v.animate().cancel()
        v.alpha = 0f
        v.translationY = dp(22).toFloat()
        v.animate().alpha(1f).translationY(0f).setStartDelay((index * step).toLong())
            .setDuration(380).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun swapHero(apply: () -> Unit) {
        val views = listOf(heroTitle, heroMeta, heroSub)
        for (v in views) {
            v.animate().cancel()
            v.alpha = 0f
            v.translationY = dp(10).toFloat()
        }
        apply()
        for ((i, v) in views.withIndex()) {
            v.animate().alpha(1f).translationY(0f).setStartDelay((i * 40).toLong())
                .setDuration(220).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    // ---------- Hero ----------
    private fun showAppHero(app: AppItem) {
        swapHero {
            heroTitle.text = app.label
            heroMeta.text = ""
            heroSub.text = when {
                app.pkg == "__theme" -> "Press OK to change theme  •  Now: " +
                    themes[prefs.getInt("theme", 0).coerceIn(0, themes.size - 1)].name
                app.intent == null -> "Press OK to restore hidden apps and reset order"
                app.tint -> "Press OK to open"
                else -> "Press OK to open  •  Hold OK for pin, hide or uninstall"
            }
        }
        setBackdrop(null)
    }

    private fun showTitleHero(t: Title, appName: String) {
        swapHero {
            heroTitle.text = t.name
            var meta = "★ %.1f   •   %s   •   %s".format(t.rating, t.year, t.kind)
            if (appName.isNotEmpty()) meta += "   •   on $appName"
            heroMeta.text = meta
            heroSub.text = t.overview
        }
        setBackdrop(t.image)
    }

    private fun setBackdrop(path: String?) {
        backdrop.animate().cancel()
        backdrop.scaleX = 1f
        backdrop.scaleY = 1f
        if (path == null) {
            Glide.with(this).clear(backdrop)
            backdrop.setImageDrawable(null)
        } else {
            Glide.with(this).load("https://image.tmdb.org/t/p/w1280$path")
                .transition(DrawableTransitionOptions.withCrossFade(250)).into(backdrop)
            // slow "Ken Burns" zoom
            backdrop.animate().scaleX(1.08f).scaleY(1.08f).setStartDelay(0)
                .setDuration(14000).setInterpolator(LinearInterpolator()).start()
        }
    }

    // ---------- Apps ----------
    private fun refresh() {
        val apps = loadApps()
        appRow.adapter = AppAdapter(apps)
        apps.firstOrNull()?.let { showAppHero(it) }
        appRow.post { appRow.getChildAt(0)?.requestFocus() }
    }

    private fun pinnedList(): MutableList<String> =
        prefs.getString("pinned", "")!!.split(",").filter { it.isNotBlank() }.toMutableList()

    private fun vec(id: Int): Drawable = try {
        ContextCompat.getDrawable(this, id)!!
    } catch (e: Exception) {
        ContextCompat.getDrawable(this, android.R.drawable.ic_menu_preferences)!!
    }

    private fun settingsItem(label: String, action: String, icon: Int) =
        AppItem("__qs_$label", label, vec(icon),
            Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), true)

    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        val seen = HashSet<String>()
        val all = ArrayList<AppItem>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || !seen.add(pkg)) continue
                val launch = Intent(Intent.ACTION_MAIN).addCategory(cat)
                    .setClassName(pkg, ri.activityInfo.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                all.add(AppItem(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm), launch))
            }
        }
        val hidden: Set<String> = prefs.getStringSet("hidden", null)?.toSet() ?: run {
            val d = all.filter { a -> junkLabels.any { a.label.lowercase().contains(it) } }
                .map { it.pkg }.toSet()
            prefs.edit().putStringSet("hidden", d).apply()
            d
        }
        val pinned = pinnedList()
        fun rank(a: AppItem): Int {
            val p = pinned.indexOf(a.pkg)
            if (p >= 0) return p
            val q = priority.indexOf(a.pkg)
            if (q >= 0) return 1000 + q
            return 5000
        }
        val sorted = all.filter { it.pkg !in hidden }
            .sortedWith(compareBy<AppItem>({ rank(it) }, { it.label.lowercase() }))
        val quick = listOf(
            settingsItem("Wi-Fi", Settings.ACTION_WIFI_SETTINGS, R.drawable.ic_wifi),
            settingsItem("Display", Settings.ACTION_DISPLAY_SETTINGS, R.drawable.ic_display),
            settingsItem("Sound", Settings.ACTION_SOUND_SETTINGS, R.drawable.ic_sound),
            settingsItem("Bluetooth", Settings.ACTION_BLUETOOTH_SETTINGS, R.drawable.ic_bluetooth),
            settingsItem("Settings", Settings.ACTION_SETTINGS, R.drawable.ic_gear)
        )
        val theme = AppItem("__theme", "Theme", vec(R.drawable.ic_palette), Intent(), true)
        val reset = AppItem("__reset", "Reset",
            ContextCompat.getDrawable(this, android.R.drawable.ic_menu_manage)!!, null, true)
        return sorted + quick + theme + reset
    }

    private fun installedPackages(): Set<String> {
        val s = HashSet<String>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in packageManager.queryIntentActivities(q, 0)) s.add(ri.activityInfo.packageName)
        }
        return s
    }

    private fun launchApp(pkg: String) {
        val i = packageManager.getLeanbackLaunchIntentForPackage(pkg)
            ?: packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { startActivity(i) } catch (e: Exception) { }
        }
    }

    private fun showOptions(app: AppItem) {
        if (app.intent == null || app.tint) return
        val pinned = pinnedList()
        val isPinned = app.pkg in pinned
        val options = arrayOf(if (isPinned) "Unpin" else "Move to front",
            "Hide this app", "Uninstall", "Cancel")
        AlertDialog.Builder(this).setTitle(app.label).setItems(options) { _, which ->
            when (which) {
                0 -> {
                    pinned.remove(app.pkg)
                    if (!isPinned) pinned.add(0, app.pkg)
                    prefs.edit().putString("pinned", pinned.joinToString(",")).apply()
                    refresh()
                }
                1 -> {
                    val h = (prefs.getStringSet("hidden", emptySet()) ?: emptySet()).toMutableSet()
                    h.add(app.pkg)
                    prefs.edit().putStringSet("hidden", h).apply()
                    refresh()
                }
                2 -> try {
                    startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.pkg))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) { }
            }
        }.show()
    }

    // ---------- Content rows (TMDB) ----------
    private fun addNotice(text: String) {
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(Color.parseColor("#C8CFE2"))
        tv.textSize = 14f
        tv.setPadding(0, dp(16), 0, 0)
        rowsContainer.addView(tv)
    }

    private fun loadContent() {
        val key = getString(R.string.tmdb_key).trim()
        if (key.isEmpty() || key.startsWith("PASTE")) {
            addNotice("Add your free TMDB key to see trending movies and shows here.")
            return
        }
        val cached = prefs.getString("cache2", null)
        val age = System.currentTimeMillis() - prefs.getLong("cache_time", 0L)
        if (cached != null) {
            try { renderRows(parseRows(JSONArray(cached))) } catch (e: Exception) { }
        }
        if (cached == null || age > 6 * 3600_000L) {
            thread {
                try {
                    val rows = fetchRows(key)
                    val json = rowsToJson(rows).toString()
                    runOnUiThread {
                        prefs.edit().putString("cache2", json)
                            .putLong("cache_time", System.currentTimeMillis()).apply()
                        renderRows(rows)
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        if (rowsContainer.childCount == 0)
                            addNotice("Couldn't load trending content. Check your internet connection.")
                    }
                }
            }
        }
    }

    private fun httpGet(url: String, key: String): String {
        val bearer = key.length > 40
        val full = if (bearer) url else url + (if (url.contains("?")) "&" else "?") + "api_key=" + key
        val c = URL(full).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 10000
        if (bearer) c.setRequestProperty("Authorization", "Bearer $key")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun fetchTitles(url: String, key: String, type: String): List<Title> {
        return try {
            val arr = JSONObject(httpGet(url, key)).getJSONArray("results")
            val items = ArrayList<Title>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val img = o.str("backdrop_path").ifEmpty { o.str("poster_path") }
                if (img.isEmpty()) continue
                val name = o.str("title").ifEmpty { o.str("name") }
                val year = o.str("release_date").ifEmpty { o.str("first_air_date") }.take(4)
                val mt = if (type.isEmpty()) o.str("media_type") else type
                items.add(Title(name, o.str("overview"), img, o.optDouble("vote_average", 0.0),
                    year, if (mt == "tv") "Show" else "Movie"))
            }
            items
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun fetchRows(key: String): List<ContentRow> {
        val base = "https://api.themoviedb.org/3"
        val rows = ArrayList<ContentRow>()
        fun add(title: String, url: String, type: String) {
            val items = fetchTitles(url, key, type)
            if (items.isNotEmpty()) rows.add(ContentRow(title, items))
        }
        add("Trending today", "$base/trending/all/day?language=en-US", "")
        for ((name, id, pkgs) in providers) {
            val q = "language=en-US&sort_by=popularity.desc&watch_region=IN" +
                "&with_watch_providers=$id&with_watch_monetization_types=flatrate"
            val m = fetchTitles("$base/discover/movie?$q", key, "movie")
            val s = fetchTitles("$base/discover/tv?$q", key, "tv")
            val merged = ArrayList<Title>()
            for (i in 0 until maxOf(m.size, s.size)) {
                if (i < m.size) merged.add(m[i])
                if (i < s.size) merged.add(s[i])
            }
            if (merged.isNotEmpty()) rows.add(ContentRow("On $name", merged.take(20), pkgs, name))
        }
        add("Coming soon", "$base/movie/upcoming?language=en-US&region=IN", "movie")
        add("Popular movies in India", "$base/movie/popular?language=en-US&region=IN", "movie")
        add("Popular shows", "$base/tv/popular?language=en-US", "tv")
        add("Top rated movies", "$base/movie/top_rated?language=en-US&region=IN", "movie")
        if (rows.isEmpty()) throw Exception("no data")
        return rows
    }

    private fun rowsToJson(rows: List<ContentRow>): JSONArray {
        val a = JSONArray()
        for (r in rows) {
            val items = JSONArray()
            for (t in r.items) items.put(JSONObject().put("n", t.name).put("o", t.overview)
                .put("i", t.image).put("r", t.rating).put("y", t.year).put("k", t.kind))
            a.put(JSONObject().put("t", r.title).put("items", items)
                .put("p", JSONArray(r.pkgs)).put("a", r.appName))
        }
        return a
    }

    private fun parseRows(a: JSONArray): List<ContentRow> {
        val rows = ArrayList<ContentRow>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val arr = o.getJSONArray("items")
            val items = ArrayList<Title>()
            for (j in 0 until arr.length()) {
                val t = arr.getJSONObject(j)
                items.add(Title(t.getString("n"), t.getString("o"), t.getString("i"),
                    t.getDouble("r"), t.getString("y"), t.getString("k")))
            }
            val p = o.optJSONArray("p")
            val pkgs = ArrayList<String>()
            if (p != null) for (k in 0 until p.length()) pkgs.add(p.getString(k))
            rows.add(ContentRow(o.getString("t"), items, pkgs, o.optString("a", "")))
        }
        return rows
    }

    private fun renderRows(rows: List<ContentRow>) {
        rowsContainer.removeAllViews()
        val installed = installedPackages()
        var idx = 0
        for (r in rows) {
            if (r.pkgs.isNotEmpty() && r.pkgs.none { it in installed }) continue
            val launchPkg = r.pkgs.firstOrNull { it in installed }
            val label = TextView(this)
            label.text = r.title
            label.setTextColor(Color.WHITE)
            label.textSize = 16f
            label.typeface = Typeface.DEFAULT_BOLD
            label.setPadding(0, dp(14), 0, dp(2))
            val rv = RecyclerView(this)
            rv.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
            rv.clipChildren = false
            rv.clipToPadding = false
            rv.setPadding(0, dp(10), 0, dp(10))
            rv.adapter = PosterAdapter(r.items, launchPkg, r.appName)
            rowsContainer.addView(label)
            rowsContainer.addView(rv, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            enter(label, idx, 90)
            enter(rv, idx, 90)
            idx++
        }
        val credit = TextView(this)
        credit.text = "This product uses the TMDB API but is not endorsed or certified by TMDB."
        credit.setTextColor(Color.parseColor("#7F889F"))
        credit.textSize = 10f
        credit.setPadding(0, dp(12), 0, 0)
        rowsContainer.addView(credit)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            scroll.smoothScrollTo(0, 0)
            appRow.getChildAt(0)?.requestFocus()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------- Adapters ----------
    inner class AppAdapter(private val items: List<AppItem>) :
        RecyclerView.Adapter<AppAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val icon: ImageView = v.findViewById(R.id.icon)
            val label: TextView = v.findViewById(R.id.label)
            val ring: View = v.findViewById(R.id.ring)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_app, p, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val app = items[pos]
            h.icon.setImageDrawable(app.image)
            h.icon.setClipToOutline(true)
            h.ring.background = ring(true, accent)
            if (app.tint) {
                h.icon.setColorFilter(Color.WHITE)
                h.icon.setPadding(dp(16), dp(16), dp(16), dp(16))
            } else {
                h.icon.clearColorFilter()
                h.icon.setPadding(0, 0, 0, 0)
            }
            h.label.text = app.label
            enter(h.itemView, minOf(pos, 10), 45)
            h.itemView.setOnFocusChangeListener { v, has ->
                v.animate().setStartDelay(0).setInterpolator(OvershootInterpolator(1.6f))
                    .scaleX(if (has) 1.15f else 1f).scaleY(if (has) 1.15f else 1f)
                    .setDuration(180).start()
                h.label.setTextColor(if (has) Color.WHITE else Color.parseColor("#B8C0D6"))
                if (has) showAppHero(app)
            }
            h.itemView.setOnClickListener {
                val launch = app.intent
                when {
                    app.pkg == "__theme" -> cycleTheme()
                    launch == null -> {
                        prefs.edit().remove("hidden").remove("pinned").apply()
                        refresh()
                    }
                    else -> try { startActivity(launch) } catch (e: Exception) { }
                }
            }
            h.itemView.setOnLongClickListener { showOptions(app); true }
        }
    }

    inner class PosterAdapter(private val items: List<Title>,
                              private val launchPkg: String?,
                              private val appName: String) :
        RecyclerView.Adapter<PosterAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val img: ImageView = v.findViewById(R.id.img)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_poster, p, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val t = items[pos]
            h.img.setClipToOutline(true)
            h.itemView.background = ring(false, accent)
            Glide.with(h.img).load("https://image.tmdb.org/t/p/w500" + t.image).centerCrop().into(h.img)
            h.itemView.setOnFocusChangeListener { v, has ->
                v.animate().setStartDelay(0).setInterpolator(OvershootInterpolator(1.4f))
                    .scaleX(if (has) 1.08f else 1f).scaleY(if (has) 1.08f else 1f)
                    .setDuration(180).start()
                if (has) showTitleHero(t, appName)
            }
            h.itemView.setOnClickListener {
                val b = AlertDialog.Builder(this@MainActivity).setTitle(t.name)
                    .setMessage("★ %.1f  •  %s  •  %s\n\n%s".format(t.rating, t.year, t.kind, t.overview))
                    .setPositiveButton("Close", null)
                if (launchPkg != null) {
                    b.setNeutralButton("Open $appName") { _, _ -> launchApp(launchPkg) }
                }
                b.show()
            }
        }
    }
}
