package com.example.gtvlauncher

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.TransitionDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

private const val HOUR = 3_600_000L
private const val IMG = "https://image.tmdb.org/t/p/"

class MainActivity : AppCompatActivity() {
    private lateinit var store: Store
    private lateinit var root: FrameLayout
    private lateinit var scrimLeft: View
    private lateinit var scrimBottom: View
    private lateinit var tabsRow: LinearLayout
    private lateinit var weather: TextView
    private lateinit var clock: TextView
    private lateinit var greeting: TextView
    private lateinit var hero: LinearLayout
    private lateinit var heroTitle: TextView
    private lateinit var heroMeta: TextView
    private lateinit var heroSub: TextView
    private lateinit var backdrop: ImageView
    private lateinit var searchPage: LinearLayout
    private lateinit var searchBox: EditText
    private lateinit var searchStatus: TextView
    private lateinit var searchGrid: RecyclerView
    private lateinit var homePage: ScrollView
    private lateinit var appRow: RecyclerView
    private lateinit var homeRows: LinearLayout
    private lateinit var moviesPage: ScrollView
    private lateinit var moviesRows: LinearLayout
    private lateinit var showsPage: ScrollView
    private lateinit var showsRows: LinearLayout
    private lateinit var appsGrid: RecyclerView
    private lateinit var libraryPage: ScrollView
    private lateinit var libraryRows: LinearLayout
    private lateinit var settingsGrid: RecyclerView
    private lateinit var pages: List<View>

    private val handler = Handler(Looper.getMainLooper())
    private val tabNames = listOf("Search", "For you", "Movies", "Shows", "Apps", "Library", "Settings")
    private val tabViews = ArrayList<TextView>()
    private var page = 1
    private var accent = Color.WHITE
    private var currentBg: Drawable? = null

    private var allApps: List<AppItem> = emptyList()
    private var lastSig = ""
    private var currentCtx = ""
    private var ctxRunnable: Runnable? = null
    private var searchRunnable: Runnable? = null
    private var searchToken = 0

    private val priority = listOf(
        "com.netflix.ninja", "com.google.android.youtube.tv", "com.amazon.firetv.youtube",
        "com.amazon.amazonvideo.livingroom", "in.startv.hotstar", "com.sonyliv",
        "com.graymatrix.did", "com.mxtech.videoplayer.ad", "org.videolan.vlc"
    )
    private val junkLabels = listOf("game center", "amazon kids", "amazon live", "minitv", "live shopping")

    private val tick = object : Runnable {
        override fun run() {
            val pattern = if (store.clock24) "HH:mm" else "h:mm a"
            clock.text = SimpleDateFormat(pattern, Locale.getDefault()).format(Date())
            val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val part = when {
                h < 12 -> "Good morning"
                h < 17 -> "Good afternoon"
                else -> "Good evening"
            }
            greeting.text = part + "   •   " +
                SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())
            handler.postDelayed(this, 30_000)
        }
    }

    // =====================================================================
    // Lifecycle
    // =====================================================================
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = Store(this)
        Tmdb.key = getString(R.string.tmdb_key).trim()
        bindViews()
        buildTabs()
        setupLists()
        applyTheme(false)
        showPage(1, false)
        loadWeather()
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
        reloadApps(false)
        if (page == 5) buildLibrary()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    private fun bindViews() {
        root = findViewById(R.id.root)
        scrimLeft = findViewById(R.id.scrimLeft)
        scrimBottom = findViewById(R.id.scrimBottom)
        tabsRow = findViewById(R.id.tabsRow)
        weather = findViewById(R.id.weather)
        clock = findViewById(R.id.clock)
        greeting = findViewById(R.id.greeting)
        hero = findViewById(R.id.hero)
        heroTitle = findViewById(R.id.heroTitle)
        heroMeta = findViewById(R.id.heroMeta)
        heroSub = findViewById(R.id.heroSub)
        backdrop = findViewById(R.id.backdrop)
        searchPage = findViewById(R.id.searchPage)
        searchBox = findViewById(R.id.searchBox)
        searchStatus = findViewById(R.id.searchStatus)
        searchGrid = findViewById(R.id.searchGrid)
        homePage = findViewById(R.id.homePage)
        appRow = findViewById(R.id.appRow)
        homeRows = findViewById(R.id.homeRows)
        moviesPage = findViewById(R.id.moviesPage)
        moviesRows = findViewById(R.id.moviesRows)
        showsPage = findViewById(R.id.showsPage)
        showsRows = findViewById(R.id.showsRows)
        appsGrid = findViewById(R.id.appsGrid)
        libraryPage = findViewById(R.id.libraryPage)
        libraryRows = findViewById(R.id.libraryRows)
        settingsGrid = findViewById(R.id.settingsGrid)
        pages = listOf(searchPage, homePage, moviesPage, showsPage, appsGrid, libraryPage, settingsGrid)
    }

    private fun setupLists() {
        appRow.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        appsGrid.layoutManager = GridLayoutManager(this, 7)
        settingsGrid.layoutManager = GridLayoutManager(this, 6)
        settingsGrid.itemAnimator = null
        searchGrid.layoutManager = GridLayoutManager(this, 4)

        searchBox.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                doSearch(v.text.toString().trim())
                true
            } else {
                false
            }
        }
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                searchRunnable?.let { handler.removeCallbacks(it) }
                val q = s?.toString()?.trim() ?: ""
                val r = Runnable { doSearch(q) }
                searchRunnable = r
                handler.postDelayed(r, 700)
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    // =====================================================================
    // Tabs & pages
    // =====================================================================
    private fun buildTabs() {
        for ((i, name) in tabNames.withIndex()) {
            val tv = TextView(this)
            tv.text = name
            tv.textSize = 15f
            tv.isFocusable = false
            tv.isClickable = true
            tv.setPadding(dpi(16), dpi(7), dpi(16), dpi(7))
            tv.setOnFocusChangeListener { _, has ->
                if (has) showPage(i, true)
                styleTab(i, has)
            }
            tv.setOnClickListener {
                showPage(i, true)
                pages[page].requestFocus()
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 0, dpi(4), 0)
            tabsRow.addView(tv, lp)
            tabViews.add(tv)
        }
    }

    private fun styleTab(i: Int, focused: Boolean) {
        val tv = tabViews[i]
        val sel = i == page
        if (focused) {
            tv.setTextColor(Color.parseColor("#101010"))
            tv.background = roundBg(this, accent, 18)
        } else {
            tv.setTextColor(if (sel) Color.WHITE else Color.parseColor("#9AA3B8"))
            tv.background = if (sel) roundBg(this, Color.parseColor("#26FFFFFF"), 18) else null
        }
        tv.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun updateTabs() {
        for (i in tabViews.indices) styleTab(i, tabViews[i].hasFocus())
    }

    private fun showPage(i: Int, animate: Boolean) {
        if (i == page && pages[i].visibility == View.VISIBLE) {
            updateTabs()
            return
        }
        page = i
        for ((k, v) in pages.withIndex()) v.visibility = if (k == i) View.VISIBLE else View.GONE
        hero.visibility = if (i == 1 || i == 2 || i == 3 || i == 5) View.VISIBLE else View.GONE
        updateTabs()
        setBackdrop(null)
        heroMeta.text = ""
        when (i) {
            2 -> { heroTitle.text = "Movies"; heroSub.text = "Popular, new and top picks by genre" }
            3 -> { heroTitle.text = "Shows"; heroSub.text = "Popular series and shows by genre" }
            5 -> { heroTitle.text = "Library"; heroSub.text = "Your recent apps and My List" }
            else -> { }
        }
        if (animate) {
            val v = pages[i]
            v.alpha = 0f
            v.translationY = dpi(14).toFloat()
            v.animate().alpha(1f).translationY(0f).setDuration(260)
                .setInterpolator(DecelerateInterpolator()).start()
        }
        when (i) {
            2 -> loadCatalog("movie")
            3 -> loadCatalog("tv")
            4 -> showAppsGrid()
            5 -> buildLibrary()
            6 -> buildSettings()
            else -> { }
        }
    }

    private fun focusHomeApp() {
        appRow.getChildAt(0)?.requestFocus()
        handler.postDelayed({
            if (page == 1 && appRow.focusedChild == null) appRow.getChildAt(0)?.requestFocus()
            for (tv in tabViews) tv.isFocusable = true
        }, 300)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.keyCode == KeyEvent.KEYCODE_DPAD_UP) {
            val f = currentFocus
            if (f != null && !tabViews.contains(f)) {
                val next = f.focusSearch(View.FOCUS_UP)
                if (next != null && tabViews.contains(next)) {
                    tabViews[page].requestFocus()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (page != 1) {
                showPage(1, true)
            } else {
                homePage.smoothScrollTo(0, 0)
            }
            focusHomeApp()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // =====================================================================
    // Theme
    // =====================================================================
    private fun applyTheme(animate: Boolean) {
        val t = Themes.current(store)
        accent = Color.parseColor(t.accent)
        val bg = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor(t.c1), Color.parseColor(t.c2), Color.parseColor(t.c3)))
        val old = currentBg
        if (animate && old != null) {
            val td = TransitionDrawable(arrayOf<Drawable>(old, bg))
            root.background = td
            td.startTransition(450)
        } else {
            root.background = bg
        }
        currentBg = bg
        val s = Color.parseColor(t.scrim)
        scrimLeft.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(withAlpha(s, 0xF2), withAlpha(s, 0x99), withAlpha(s, 0x00)))
        scrimBottom.background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
            intArrayOf(withAlpha(s, 0xFF), withAlpha(s, 0x00)))
        recolor(root)
        updateTabs()
    }

    private fun recolor(v: View) {
        val tag = v.tag
        if (tag == "ringO") v.background = ringDrawable(this, true, accent)
        if (tag == "ringR") v.background = ringDrawable(this, false, accent)
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) recolor(v.getChildAt(i))
        }
    }

    private fun cycleTheme() {
        store.theme = (store.theme + 1) % Themes.all.size
        applyTheme(true)
        Toast.makeText(this, "Theme: " + Themes.all[store.theme].name, Toast.LENGTH_SHORT).show()
    }

    // =====================================================================
    // Animations & hero
    // =====================================================================
    private fun enter(v: View, index: Int, step: Int) {
        v.animate().cancel()
        v.alpha = 0f
        v.translationY = dpi(22).toFloat()
        v.animate().alpha(1f).translationY(0f).setStartDelay((index * step).toLong())
            .setDuration(380).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun swapHero(apply: () -> Unit) {
        val views = listOf(heroTitle, heroMeta, heroSub)
        for (v in views) {
            v.animate().cancel()
            v.alpha = 0f
            v.translationY = dpi(10).toFloat()
        }
        apply()
        for ((i, v) in views.withIndex()) {
            v.animate().alpha(1f).translationY(0f).setStartDelay((i * 40).toLong())
                .setDuration(220).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun showAppHero(app: AppItem) {
        val prov = Tmdb.providerByPackage(app.pkg)
        swapHero {
            heroTitle.text = app.label
            heroMeta.text = ""
            heroSub.text = if (prov != null)
                "Press OK to open  •  Hold OK for more  •  Showing what's on " + prov.name
            else
                "Press OK to open  •  Hold OK to pin, hide or uninstall"
        }
        setBackdrop(null)
    }

    private fun showTitleHero(t: Title) {
        swapHero {
            heroTitle.text = t.name
            heroMeta.text = "★ %.1f   •   %s   •   %s".format(t.rating, t.year, t.kind)
            heroSub.text = t.overview
        }
        setBackdrop(t.image)
    }

    private fun setBackdrop(path: String?) {
        backdrop.animate().cancel()
        backdrop.scaleX = 1f
        backdrop.scaleY = 1f
        if (path == null || path.isEmpty()) {
            Glide.with(this).clear(backdrop)
            backdrop.setImageDrawable(null)
        } else {
            Glide.with(this).load(IMG + "w1280" + path)
                .transition(DrawableTransitionOptions.withCrossFade(250)).into(backdrop)
            backdrop.animate().scaleX(1.08f).scaleY(1.08f).setStartDelay(0)
                .setDuration(14000).setInterpolator(LinearInterpolator()).start()
        }
    }

    // =====================================================================
    // Apps
    // =====================================================================
    private fun loadAllApps(): List<AppItem> {
        val pm = packageManager
        val seen = HashSet<String>()
        val all = ArrayList<AppItem>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || !seen.add(pkg)) continue
                all.add(AppItem(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm)))
            }
        }
        return all
    }

    private fun effectiveHidden(): Set<String> {
        if (!store.hasHidden()) {
            val d = allApps.filter { a -> junkLabels.any { a.label.lowercase().contains(it) } }
                .map { it.pkg }.toSet()
            store.setHidden(d)
            return d
        }
        return store.hidden()
    }

    private fun sortApps(list: List<AppItem>): List<AppItem> {
        val pinned = store.pinned()
        return list.sortedWith(compareBy<AppItem>(
            { val p = pinned.indexOf(it.pkg); if (p >= 0) p else 9999 },
            { -store.launchCount(it.pkg) },
            { val q = priority.indexOf(it.pkg); if (q >= 0) q else 9999 },
            { it.label.lowercase() }
        ))
    }

    private fun reloadApps(force: Boolean) {
        allApps = loadAllApps()
        val hidden = effectiveHidden()
        val sorted = sortApps(allApps.filter { it.pkg !in hidden })
        val sig = sorted.joinToString("|") { it.pkg }
        if (force || sig != lastSig) {
            lastSig = sig
            appRow.adapter = AppAdapter(sorted, R.layout.item_app, true)
            if (page == 1) focusHomeApp()
            if (page == 4) showAppsGrid()
        }
    }

    private fun showAppsGrid() {
        val hidden = effectiveHidden()
        val list = ArrayList<AppItem>()
        for (a in allApps.sortedBy { it.label.lowercase() }) {
            if (a.pkg in hidden) {
                if (store.showHidden) list.add(a.copy(label = a.label + " (hidden)"))
            } else {
                list.add(a)
            }
        }
        appsGrid.adapter = AppAdapter(list, R.layout.item_app_grid, false)
    }

    private fun launchApp(app: AppItem) {
        if (!launchPackage(this, app.pkg, store))
            Toast.makeText(this, "Can't open " + app.label, Toast.LENGTH_SHORT).show()
    }

    private fun showAppOptions(app: AppItem) {
        val pinned = store.pinned()
        val isPinned = app.pkg in pinned
        val hidden = store.hidden()
        val isHidden = app.pkg in hidden
        val options = arrayOf(
            if (isPinned) "Unpin from front" else "Move to front",
            if (isHidden) "Unhide" else "Hide this app",
            "App info",
            "Uninstall",
            "Cancel"
        )
        AlertDialog.Builder(this).setTitle(app.label.removeSuffix(" (hidden)"))
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        pinned.remove(app.pkg)
                        if (!isPinned) pinned.add(0, app.pkg)
                        store.setPinned(pinned)
                        reloadApps(true)
                    }
                    1 -> {
                        if (isHidden) hidden.remove(app.pkg) else hidden.add(app.pkg)
                        store.setHidden(hidden)
                        reloadApps(true)
                    }
                    2 -> openIntent(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + app.pkg)))
                    3 -> openIntent(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.pkg)))
                    else -> { }
                }
            }.show()
    }

    private fun openIntent(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Not available on this device", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openSystem(action: String) {
        openIntent(Intent(action))
    }

    // =====================================================================
    // Home: app-specific content
    // =====================================================================
    private fun hasKey(): Boolean = Tmdb.key.isNotEmpty() && !Tmdb.key.startsWith("PASTE")

    private fun onHomeAppFocused(app: AppItem) {
        showAppHero(app)
        ctxRunnable?.let { handler.removeCallbacks(it) }
        val r = Runnable { loadHomeContext(Tmdb.providerByPackage(app.pkg)) }
        ctxRunnable = r
        handler.postDelayed(r, 450)
    }

    private fun loadHomeContext(prov: Provider?) {
        val ctx = if (prov != null) prov.id.toString() else "default"
        if (ctx == currentCtx && homeRows.childCount > 0) return
        currentCtx = ctx
        val ck = "ctx_" + ctx
        val cached = store.cacheGet(ck, 6 * HOUR)
        if (cached != null) {
            renderRows(homeRows, rowsFromJson(cached), prov == null)
            return
        }
        homeRows.removeAllViews()
        if (!hasKey()) {
            addNotice(homeRows, "Add your free TMDB key to see content here.")
            return
        }
        addNotice(homeRows, "Loading…")
        thread {
            var rows = if (prov != null) Tmdb.providerRows(prov) else Tmdb.homeRows()
            if (rows.isEmpty() && prov != null) rows = Tmdb.homeRows()
            if (rows.isNotEmpty()) store.cachePut(ck, rowsToJson(rows))
            val result = rows
            runOnUiThread {
                if (currentCtx == ctx) {
                    if (result.isNotEmpty()) {
                        renderRows(homeRows, result, prov == null)
                    } else {
                        homeRows.removeAllViews()
                        addNotice(homeRows, "Couldn't load content. Check your internet connection.")
                    }
                }
            }
        }
    }

    private fun loadCatalog(type: String) {
        val container = if (type == "movie") moviesRows else showsRows
        if (container.childCount > 0) return
        val ck = "cat_" + type
        val cached = store.cacheGet(ck, 12 * HOUR)
        if (cached != null) {
            renderRows(container, rowsFromJson(cached), false)
            return
        }
        if (!hasKey()) {
            addNotice(container, "Add your free TMDB key to see content here.")
            return
        }
        addNotice(container, "Loading…")
        thread {
            val rows = Tmdb.catalogRows(type)
            if (rows.isNotEmpty()) store.cachePut(ck, rowsToJson(rows))
            runOnUiThread {
                container.removeAllViews()
                if (rows.isNotEmpty()) renderRows(container, rows, false)
                else addNotice(container, "Couldn't load content. Check your internet connection.")
            }
        }
    }

    // =====================================================================
    // Library
    // =====================================================================
    private fun buildLibrary() {
        libraryRows.removeAllViews()
        var idx = 0
        val recentApps = store.recents().mapNotNull { pkg -> allApps.firstOrNull { it.pkg == pkg } }
        if (recentApps.isNotEmpty()) {
            val label = sectionLabel("Recently opened")
            val rv = hRecycler()
            rv.adapter = AppAdapter(recentApps, R.layout.item_app, false)
            libraryRows.addView(label)
            libraryRows.addView(rv, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            enter(label, idx, 90)
            enter(rv, idx, 90)
            idx++
        }
        val list = store.myList()
        if (list.isNotEmpty()) addRow(libraryRows, ContentRow("My List", list), idx++)
        if (idx == 0) {
            addNotice(libraryRows,
                "Nothing here yet. Open apps from the launcher and add titles to My List " +
                    "(hold OK on any poster, or use the details screen).")
        }
    }

    // =====================================================================
    // Search
    // =====================================================================
    private fun doSearch(q: String) {
        if (q.length < 2) return
        if (!hasKey()) {
            searchStatus.text = "Add your free TMDB key to use search."
            return
        }
        val token = ++searchToken
        searchStatus.text = "Searching…"
        thread {
            val r = Tmdb.search(q)
            runOnUiThread {
                if (token == searchToken) {
                    searchGrid.adapter = PosterAdapter(r, R.layout.item_poster_grid)
                    searchStatus.text = if (r.isEmpty()) "No results for \"" + q + "\"" else ""
                }
            }
        }
    }

    // =====================================================================
    // Settings page
    // =====================================================================
    private fun buildSettings() {
        val t = ArrayList<Tile>()
        fun sys(emoji: String, label: String, action: String) {
            t.add(Tile(emoji, label) { openSystem(action) })
        }
        sys("📶", "Wi-Fi", Settings.ACTION_WIFI_SETTINGS)
        sys("🎧", "Bluetooth", Settings.ACTION_BLUETOOTH_SETTINGS)
        sys("🖥", "Display", Settings.ACTION_DISPLAY_SETTINGS)
        sys("🔊", "Sound", Settings.ACTION_SOUND_SETTINGS)
        sys("🌐", "Network", Settings.ACTION_WIRELESS_SETTINGS)
        sys("🕒", "Date & time", Settings.ACTION_DATE_SETTINGS)
        sys("🈯", "Language", Settings.ACTION_LOCALE_SETTINGS)
        sys("⌨", "Keyboard", Settings.ACTION_INPUT_METHOD_SETTINGS)
        sys("📦", "Apps", Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS)
        sys("💾", "Storage", Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
        sys("♿", "Accessibility", Settings.ACTION_ACCESSIBILITY_SETTINGS)
        sys("ℹ", "About device", Settings.ACTION_DEVICE_INFO_SETTINGS)
        sys("🛠", "Developer", Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
        sys("⚙", "All settings", Settings.ACTION_SETTINGS)

        t.add(Tile("🎨", "Theme: " + Themes.all[store.theme].name) {
            cycleTheme()
            rebuildSettingsKeepFocus()
        })
        t.add(Tile(if (store.showHidden) "👁" else "🙈",
            if (store.showHidden) "Hidden apps: shown" else "Hidden apps: off") {
            store.showHidden = !store.showHidden
            rebuildSettingsKeepFocus()
        })
        t.add(Tile("🕐", if (store.clock24) "Clock: 24-hour" else "Clock: 12-hour") {
            store.clock24 = !store.clock24
            handler.post(tick)
            rebuildSettingsKeepFocus()
        })
        t.add(Tile("🔄", "Refresh content") {
            store.clearCache()
            homeRows.removeAllViews()
            moviesRows.removeAllViews()
            showsRows.removeAllViews()
            currentCtx = ""
            loadWeather()
            Toast.makeText(this, "Content will refresh", Toast.LENGTH_SHORT).show()
        })
        t.add(Tile("↩", "Reset layout") {
            store.resetLayout()
            lastSig = ""
            reloadApps(true)
            Toast.makeText(this, "Apps order reset", Toast.LENGTH_SHORT).show()
        })
        settingsGrid.adapter = TileAdapter(t)
    }

    private fun rebuildSettingsKeepFocus() {
        val f = settingsGrid.focusedChild
        val pos = if (f != null) settingsGrid.getChildAdapterPosition(f) else -1
        buildSettings()
        if (pos >= 0) {
            settingsGrid.post { settingsGrid.findViewHolderForAdapterPosition(pos)?.itemView?.requestFocus() }
        }
    }

    // =====================================================================
    // Weather
    // =====================================================================
    private fun loadWeather() {
        val c = store.cacheGet("weather", 30 * 60_000L)
        if (c != null) {
            weather.text = c
            return
        }
        thread {
            val w = Weather.fetch()
            if (w != null) {
                store.cachePut("weather", w)
                runOnUiThread { weather.text = w }
            }
        }
    }

    // =====================================================================
    // Row rendering helpers
    // =====================================================================
    private fun sectionLabel(text: String): TextView {
        val label = TextView(this)
        label.text = text
        label.setTextColor(Color.WHITE)
        label.textSize = 16f
        label.typeface = Typeface.DEFAULT_BOLD
        label.setPadding(0, dpi(14), 0, dpi(2))
        return label
    }

    private fun hRecycler(): RecyclerView {
        val rv = RecyclerView(this)
        rv.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rv.clipChildren = false
        rv.clipToPadding = false
        rv.setPadding(0, dpi(10), 0, dpi(10))
        return rv
    }

    private fun addNotice(container: LinearLayout, text: String) {
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(Color.parseColor("#C8CFE2"))
        tv.textSize = 14f
        tv.setPadding(0, dpi(16), 0, 0)
        container.addView(tv)
    }

    private fun addRow(container: LinearLayout, r: ContentRow, idx: Int) {
        val label = sectionLabel(r.title)
        val rv = hRecycler()
        rv.adapter = PosterAdapter(r.items, R.layout.item_poster)
        container.addView(label)
        container.addView(rv, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        enter(label, idx, 90)
        enter(rv, idx, 90)
    }

    private fun renderRows(container: LinearLayout, rows: List<ContentRow>, withMyList: Boolean) {
        container.removeAllViews()
        var idx = 0
        if (withMyList) {
            val l = store.myList()
            if (l.isNotEmpty()) addRow(container, ContentRow("My List", l), idx++)
        }
        for (r in rows) addRow(container, r, idx++)
        val credit = TextView(this)
        credit.text = "This product uses the TMDB API but is not endorsed or certified by TMDB."
        credit.setTextColor(Color.parseColor("#7F889F"))
        credit.textSize = 10f
        credit.setPadding(0, dpi(12), 0, 0)
        container.addView(credit)
    }

    private fun openDetail(t: Title) {
        startActivity(Intent(this, DetailActivity::class.java).putExtra("title", t.toJson().toString()))
    }

    // =====================================================================
    // Adapters
    // =====================================================================
    inner class AppAdapter(
        private val items: List<AppItem>,
        private val layoutRes: Int,
        private val isHome: Boolean
    ) : RecyclerView.Adapter<AppAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val icon: ImageView = v.findViewById(R.id.icon)
            val label: TextView = v.findViewById(R.id.label)
            val ring: View = v.findViewById(R.id.ring)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
            VH(LayoutInflater.from(p.context).inflate(layoutRes, p, false))

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val app = items[pos]
            h.icon.setImageDrawable(app.image)
            h.icon.setClipToOutline(true)
            h.ring.background = ringDrawable(this@MainActivity, true, accent)
            h.ring.tag = "ringO"
            h.label.text = app.label
            enter(h.itemView, minOf(pos, 10), 45)
            h.itemView.setOnFocusChangeListener { v, has ->
                v.animate().setStartDelay(0).setInterpolator(OvershootInterpolator(1.6f))
                    .scaleX(if (has) 1.15f else 1f).scaleY(if (has) 1.15f else 1f)
                    .setDuration(180).start()
                h.label.setTextColor(if (has) Color.WHITE else Color.parseColor("#B8C0D6"))
                if (has) {
                    if (isHome) onHomeAppFocused(app) else showAppHero(app)
                }
            }
            h.itemView.setOnClickListener { launchApp(app) }
            h.itemView.setOnLongClickListener {
                showAppOptions(app)
                true
            }
        }
    }

    inner class PosterAdapter(
        private val items: List<Title>,
        private val layoutRes: Int
    ) : RecyclerView.Adapter<PosterAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val img: ImageView = v.findViewById(R.id.img)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
            VH(LayoutInflater.from(p.context).inflate(layoutRes, p, false))

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val t = items[pos]
            h.img.setClipToOutline(true)
            h.itemView.background = ringDrawable(this@MainActivity, false, accent)
            h.itemView.tag = "ringR"
            Glide.with(h.img).load(IMG + "w500" + t.image).centerCrop().into(h.img)
            h.itemView.setOnFocusChangeListener { v, has ->
                v.animate().setStartDelay(0).setInterpolator(OvershootInterpolator(1.4f))
                    .scaleX(if (has) 1.08f else 1f).scaleY(if (has) 1.08f else 1f)
                    .setDuration(180).start()
                if (has) showTitleHero(t)
            }
            h.itemView.setOnClickListener { openDetail(t) }
            h.itemView.setOnLongClickListener {
                val added = store.toggleList(t)
                Toast.makeText(this@MainActivity,
                    if (added) "Added to My List" else "Removed from My List",
                    Toast.LENGTH_SHORT).show()
                true
            }
        }
    }

    inner class TileAdapter(private val tiles: List<Tile>) :
        RecyclerView.Adapter<TileAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val emoji: TextView = v.findViewById(R.id.emoji)
            val label: TextView = v.findViewById(R.id.label)
            val ring: View = v.findViewById(R.id.ring)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_tile, p, false))

        override fun getItemCount(): Int = tiles.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val tile = tiles[pos]
            h.emoji.text = tile.emoji
            h.label.text = tile.label
            h.ring.background = ringDrawable(this@MainActivity, true, accent)
            h.ring.tag = "ringO"
            h.itemView.setOnFocusChangeListener { v, has ->
                v.animate().setStartDelay(0).setInterpolator(OvershootInterpolator(1.6f))
                    .scaleX(if (has) 1.12f else 1f).scaleY(if (has) 1.12f else 1f)
                    .setDuration(180).start()
                h.label.setTextColor(if (has) Color.WHITE else Color.parseColor("#B8C0D6"))
            }
            h.itemView.setOnClickListener { tile.action() }
        }
    }
}
