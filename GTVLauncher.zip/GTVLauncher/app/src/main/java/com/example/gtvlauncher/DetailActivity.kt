package com.example.gtvlauncher

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import org.json.JSONObject
import kotlin.concurrent.thread

class DetailActivity : AppCompatActivity() {
    private lateinit var store: Store
    private var accent = Color.WHITE
    private lateinit var actionRow: LinearLayout
    private lateinit var watchRow: LinearLayout
    private lateinit var watchLabel: TextView
    private lateinit var watchNote: TextView

    private fun lp(): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        p.setMargins(0, 0, dpi(10), 0)
        return p
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        store = Store(this)
        Tmdb.key = getString(R.string.tmdb_key).trim()
        val raw = intent.getStringExtra("title")
        if (raw == null) {
            finish()
            return
        }
        val t = Title.fromJson(JSONObject(raw))

        val th = Themes.current(store)
        accent = Color.parseColor(th.accent)
        findViewById<View>(R.id.root).background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor(th.c1), Color.parseColor(th.c2), Color.parseColor(th.c3)))
        val s = Color.parseColor(th.scrim)
        findViewById<View>(R.id.scrimLeft).background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(withAlpha(s, 0xF5), withAlpha(s, 0xB0), withAlpha(s, 0x30)))
        findViewById<View>(R.id.scrimBottom).background = GradientDrawable(
            GradientDrawable.Orientation.BOTTOM_TOP,
            intArrayOf(withAlpha(s, 0xFF), withAlpha(s, 0x00)))

        findViewById<TextView>(R.id.title).text = t.name
        findViewById<TextView>(R.id.meta).text =
            "★ %.1f   •   %s   •   %s".format(t.rating, t.year, t.kind)
        findViewById<TextView>(R.id.overview).text =
            if (t.overview.isEmpty()) "No description available." else t.overview
        if (t.image.isNotEmpty()) {
            Glide.with(this).load("https://image.tmdb.org/t/p/w1280" + t.image)
                .centerCrop().into(findViewById<ImageView>(R.id.backdrop))
        }

        actionRow = findViewById(R.id.actionRow)
        watchRow = findViewById(R.id.watchRow)
        watchLabel = findViewById(R.id.watchLabel)
        watchNote = findViewById(R.id.watchNote)

        val listPill = pill(this, if (store.inList(t)) "✓  In My List" else "＋  My List", accent) { }
        listPill.setOnClickListener {
            val added = store.toggleList(t)
            listPill.text = if (added) "✓  In My List" else "＋  My List"
            Toast.makeText(this, if (added) "Added to My List" else "Removed from My List",
                Toast.LENGTH_SHORT).show()
        }
        actionRow.addView(listPill, lp())
        actionRow.addView(pill(this, "Close", accent) { finish() }, lp())
        listPill.requestFocus()

        thread {
            val d = Tmdb.details(t)
            runOnUiThread {
                if (d != null) bind(d) else watchNote.text = "Streaming info is unavailable right now."
            }
        }
    }

    private fun bind(d: Detail) {
        val g = findViewById<TextView>(R.id.genres)
        val line = listOf(d.genres, d.runtime).filter { it.isNotEmpty() }.joinToString("   •   ")
        g.text = line
        if (d.cast.isNotEmpty()) findViewById<TextView>(R.id.cast).text = "Cast: " + d.cast

        if (d.trailerKey.isNotEmpty()) {
            actionRow.addView(pill(this, "▶  Trailer", accent) { openTrailer(d.trailerKey) }, 0, lp())
        }

        val installed = installedPackages(this)
        val others = ArrayList<String>()
        var shown = 0
        for ((id, name) in d.providers) {
            val prov = Tmdb.providerById(id)
            val pkg = prov?.pkgs?.firstOrNull { it in installed }
            if (pkg != null && shown < 4) {
                watchRow.addView(pill(this, "▶  " + name, accent) {
                    if (!launchPackage(this, pkg, store))
                        Toast.makeText(this, "Can't open " + name, Toast.LENGTH_SHORT).show()
                }, lp())
                shown++
            } else {
                others.add(name)
            }
        }
        if (shown > 0) {
            watchLabel.visibility = View.VISIBLE
            if (shown == 1 && watchRow.childCount > 0) watchRow.getChildAt(0).requestFocus()
            if (others.isNotEmpty()) watchNote.text = "Also on: " + others.joinToString(", ")
        } else if (others.isNotEmpty()) {
            watchNote.text = "Available on: " + others.joinToString(", ") + " (not installed here)"
        } else {
            watchNote.text = "Not on streaming apps in India right now (may be rent or buy only)."
        }
    }

    private fun openTrailer(key: String) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=" + key))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val installed = installedPackages(this)
        for (yt in listOf("com.amazon.firetv.youtube", "com.google.android.youtube.tv")) {
            if (yt in installed) {
                i.setPackage(yt)
                break
            }
        }
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open the trailer on this device", Toast.LENGTH_SHORT).show()
        }
    }
}
