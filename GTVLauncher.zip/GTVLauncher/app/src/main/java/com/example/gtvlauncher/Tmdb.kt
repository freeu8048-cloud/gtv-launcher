package com.example.gtvlauncher

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun httpGet(url: String, bearer: String? = null): String {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 10000
    c.readTimeout = 12000
    if (bearer != null) c.setRequestProperty("Authorization", "Bearer " + bearer)
    return c.inputStream.bufferedReader().use { it.readText() }
}

class Provider(val id: Int, val name: String, val pkgs: List<String>)

class Detail(
    val genres: String, val runtime: String, val tagline: String, val cast: String,
    val trailerKey: String, val providers: List<Pair<Int, String>>
)

object Tmdb {
    private const val BASE = "https://api.themoviedb.org/3"
    var key: String = ""

    val providers = listOf(
        Provider(8, "Netflix", listOf("com.netflix.ninja")),
        Provider(119, "Prime Video", listOf("com.amazon.amazonvideo.livingroom")),
        Provider(122, "Hotstar", listOf("in.startv.hotstar", "in.startv.hotstar.dplus.tv", "in.startv.hotstar.dplus")),
        Provider(232, "ZEE5", listOf("com.graymatrix.did")),
        Provider(237, "SonyLIV", listOf("com.sonyliv")),
        Provider(350, "Apple TV+", listOf("com.apple.atve.amazon.appletv")),
        Provider(309, "Sun NXT", listOf("com.suntv.sunnxt")),
        Provider(561, "Lionsgate Play", listOf("com.lionsgateplay.videoapp")),
        Provider(218, "Eros Now", listOf("com.erosnow"))
    )

    fun providerByPackage(pkg: String): Provider? = providers.firstOrNull { pkg in it.pkgs }
    fun providerById(id: Int): Provider? = providers.firstOrNull { it.id == id }

    private val movieGenres = listOf(
        Pair(28, "Action"), Pair(35, "Comedy"), Pair(18, "Drama"), Pair(53, "Thriller"),
        Pair(878, "Sci-Fi"), Pair(10749, "Romance"), Pair(27, "Horror"), Pair(16, "Animation"),
        Pair(80, "Crime"), Pair(10751, "Family")
    )
    private val tvGenres = listOf(
        Pair(10759, "Action & Adventure"), Pair(35, "Comedy"), Pair(18, "Drama"), Pair(80, "Crime"),
        Pair(10765, "Sci-Fi & Fantasy"), Pair(9648, "Mystery"), Pair(16, "Animation"), Pair(10751, "Family")
    )

    private fun get(path: String): String {
        return if (key.length > 40) httpGet(BASE + path, key)
        else httpGet(BASE + path + (if (path.contains("?")) "&" else "?") + "api_key=" + key)
    }

    private fun parseTitles(json: String, defaultType: String): List<Title> {
        val arr = JSONObject(json).getJSONArray("results")
        val out = ArrayList<Title>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val type = if (defaultType.isEmpty()) o.s("media_type") else defaultType
            if (type != "movie" && type != "tv") continue
            val b = o.s("backdrop_path")
            val p = o.s("poster_path")
            if (b.isEmpty() && p.isEmpty()) continue
            val name = o.s("title").ifEmpty { o.s("name") }
            val year = o.s("release_date").ifEmpty { o.s("first_air_date") }.take(4)
            out.add(Title(o.optLong("id"), type, name, o.s("overview"), b, p,
                o.optDouble("vote_average", 0.0), year))
        }
        return out
    }

    private fun titles(path: String, type: String): List<Title> {
        return try {
            parseTitles(get(path), type)
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun mix(a: List<Title>, b: List<Title>): List<Title> {
        val out = ArrayList<Title>()
        for (i in 0 until maxOf(a.size, b.size)) {
            if (i < a.size) out.add(a[i])
            if (i < b.size) out.add(b[i])
        }
        return out.take(20)
    }

    fun homeRows(): List<ContentRow> {
        val rows = ArrayList<ContentRow>()
        fun add(t: String, path: String, type: String) {
            val l = titles(path, type)
            if (l.isNotEmpty()) rows.add(ContentRow(t, l))
        }
        add("Trending today", "/trending/all/day?language=en-US", "")
        add("Popular movies in India", "/movie/popular?language=en-US&region=IN", "movie")
        add("Popular shows", "/tv/popular?language=en-US", "tv")
        add("Coming soon", "/movie/upcoming?language=en-US&region=IN", "movie")
        add("Top rated movies", "/movie/top_rated?language=en-US&region=IN", "movie")
        return rows
    }

    fun providerRows(p: Provider): List<ContentRow> {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val q = "language=en-US&watch_region=IN&with_watch_providers=" + p.id +
            "&with_watch_monetization_types=flatrate"
        val rows = ArrayList<ContentRow>()
        fun add(t: String, items: List<Title>) {
            if (items.isNotEmpty()) rows.add(ContentRow(t, items.take(20)))
        }
        val pm = titles("/discover/movie?" + q + "&sort_by=popularity.desc", "movie")
        val ps = titles("/discover/tv?" + q + "&sort_by=popularity.desc", "tv")
        add("Popular on " + p.name, mix(pm, ps))
        add("Movies on " + p.name, pm)
        add("Shows on " + p.name, ps)
        add("New on " + p.name, mix(
            titles("/discover/movie?" + q + "&sort_by=primary_release_date.desc&primary_release_date.lte=" + today, "movie"),
            titles("/discover/tv?" + q + "&sort_by=first_air_date.desc&first_air_date.lte=" + today, "tv")))
        add("Top rated on " + p.name, mix(
            titles("/discover/movie?" + q + "&sort_by=vote_average.desc&vote_count.gte=300", "movie"),
            titles("/discover/tv?" + q + "&sort_by=vote_average.desc&vote_count.gte=200", "tv")))
        return rows
    }

    fun catalogRows(type: String): List<ContentRow> {
        val rows = ArrayList<ContentRow>()
        fun add(t: String, path: String) {
            val l = titles(path, type)
            if (l.isNotEmpty()) rows.add(ContentRow(t, l))
        }
        if (type == "movie") {
            add("Popular in India", "/movie/popular?language=en-US&region=IN")
            add("Now playing", "/movie/now_playing?language=en-US&region=IN")
            for ((id, name) in movieGenres)
                add(name, "/discover/movie?language=en-US&sort_by=popularity.desc&with_genres=" + id)
        } else {
            add("Popular shows", "/tv/popular?language=en-US")
            add("On the air", "/tv/on_the_air?language=en-US")
            for ((id, name) in tvGenres)
                add(name, "/discover/tv?language=en-US&sort_by=popularity.desc&with_genres=" + id)
        }
        return rows
    }

    fun search(q: String): List<Title> =
        titles("/search/multi?language=en-US&include_adult=false&query=" + URLEncoder.encode(q, "UTF-8"), "")

    fun details(t: Title): Detail? {
        return try {
            val o = JSONObject(get("/" + t.type + "/" + t.id +
                "?language=en-US&append_to_response=videos,credits,watch/providers"))
            val g = ArrayList<String>()
            val ga = o.optJSONArray("genres")
            if (ga != null) for (i in 0 until ga.length()) g.add(ga.getJSONObject(i).s("name"))
            var runtime = ""
            if (t.type == "movie") {
                val m = o.optInt("runtime", 0)
                if (m > 0) runtime = (m / 60).toString() + "h " + (m % 60).toString() + "m"
            } else {
                val n = o.optInt("number_of_seasons", 0)
                if (n > 0) runtime = n.toString() + (if (n == 1) " season" else " seasons")
            }
            val cast = ArrayList<String>()
            val ca = o.optJSONObject("credits")?.optJSONArray("cast")
            if (ca != null) for (i in 0 until minOf(6, ca.length())) cast.add(ca.getJSONObject(i).s("name"))
            var trailer = ""
            val va = o.optJSONObject("videos")?.optJSONArray("results")
            if (va != null) {
                for (pass in 0..1) {
                    val want = if (pass == 0) "Trailer" else "Teaser"
                    for (i in 0 until va.length()) {
                        val v = va.getJSONObject(i)
                        if (trailer.isEmpty() && v.s("site") == "YouTube" && v.s("type") == want)
                            trailer = v.s("key")
                    }
                }
            }
            val prov = ArrayList<Pair<Int, String>>()
            val inn = o.optJSONObject("watch/providers")?.optJSONObject("results")?.optJSONObject("IN")
            if (inn != null) {
                for (k in listOf("flatrate", "free", "ads")) {
                    val a = inn.optJSONArray(k)
                    if (a != null) {
                        for (i in 0 until a.length()) {
                            val pr = a.getJSONObject(i)
                            val id = pr.optInt("provider_id")
                            if (prov.none { it.first == id }) prov.add(Pair(id, pr.s("provider_name")))
                        }
                    }
                }
            }
            Detail(g.joinToString("  •  "), runtime, o.s("tagline"), cast.joinToString(", "), trailer, prov)
        } catch (e: Exception) {
            null
        }
    }
}

object Weather {
    private fun icon(code: Int): String = when (code) {
        0 -> "☀"
        1, 2 -> "⛅"
        3 -> "☁"
        45, 48 -> "🌫"
        in 51..67 -> "🌧"
        in 71..77 -> "❄"
        in 80..82 -> "🌦"
        in 95..99 -> "⛈"
        else -> "🌡"
    }

    fun fetch(): String? {
        return try {
            val ip = JSONObject(httpGet("https://ipwho.is/"))
            val lat = ip.optDouble("latitude")
            val lon = ip.optDouble("longitude")
            if (lat.isNaN() || lon.isNaN()) {
                null
            } else {
                val city = ip.s("city")
                val w = JSONObject(httpGet("https://api.open-meteo.com/v1/forecast?latitude=" + lat +
                    "&longitude=" + lon + "&current_weather=true")).getJSONObject("current_weather")
                val temp = Math.round(w.getDouble("temperature")).toInt()
                val code = w.getInt("weathercode")
                icon(code) + " " + temp + "°C" + (if (city.isNotEmpty()) "  " + city else "")
            }
        } catch (e: Exception) {
            null
        }
    }
}
